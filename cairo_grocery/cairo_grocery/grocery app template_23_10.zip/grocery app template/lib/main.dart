import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'app/notifier/dark_mode.dart';
import 'app/routes/app_pages.dart';
import 'base/color_data.dart';
import 'base/my_custom_scroll_behavior.dart';
import 'base/restart_controller.dart';
import 'generated/l10n.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);

  runApp(RestartController(
    child: ChangeNotifierProvider(
        create: (context) => DarkMode(context), child: const MyApp()),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    var darkThemeProvider = Provider.of<DarkMode>(context);

    return MaterialApp(
      scrollBehavior: MyCustomScrollBehavior(),
      debugShowCheckedModeBanner: false,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        S.delegate,
      ],
      title: 'Grocery',
      initialRoute: "/",
      theme: getLightThemeData(),
      darkTheme: getDarkThemeData(),
      themeMode: (darkThemeProvider.darkMode) ? ThemeMode.dark : ThemeMode.light,
      routes: AppPages.routes,
    );
  }
}
