// ignore_for_file: depend_on_referenced_packages, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:grocery/base/color_data.dart';
import 'package:grocery/base/constant.dart';
import 'package:grocery/base/resizer/fetch_pixels.dart';
import 'package:grocery/base/widget_utils.dart';
import 'package:syncfusion_flutter_sliders/sliders.dart';
import 'package:syncfusion_flutter_core/theme.dart';

import '../../data/data_file.dart';
import '../../models/model_category.dart';

class CategoryListScreen extends StatefulWidget {
  const CategoryListScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _CategoryListScreen();
  }
}

class _CategoryListScreen extends State<CategoryListScreen> {
  TextEditingController edtController = TextEditingController();
  List<ModelCategory> catList = DataFile.getAllCategoryList();

  backClick() {
    Constant.backToPrev(context);
  }

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 1007);
    double defSpace = FetchPixels.getDefaultHorSpaceFigma(context);
    EdgeInsets edgeInsets = EdgeInsets.symmetric(horizontal: defSpace);
    int totalCountCat = 2;
    double width = MediaQuery.of(context).size.width;
    double gridWidth = (width) / totalCountCat;
    double gridHeight = FetchPixels.getPixelWidth(206);

    return WillPopScope(
      onWillPop: () async {
        backClick();
        return false;
      },
      child: Scaffold(
        body: SizedBox(
          width: double.infinity,
          height: double.infinity,
          child: buildListView(context, edgeInsets, totalCountCat, gridWidth, gridHeight, defSpace),
        ),
        backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
        appBar: getInVisibleAppBar(),
      ),
    );
  }

  ListView buildListView(BuildContext context, EdgeInsets edgeInsets, int totalCountCat, double gridWidth, double gridHeight, double defSpace) {
    return ListView(
          primary: true,
          shrinkWrap: true,
          padding: EdgeInsets.zero,
          children: [
            getToolbarFigmaWidget(context, "Categories", () {
              backClick();
            }, withBack: true, settingVisible: false),
            getPaddingWidget(
                edgeInsets,
                InkWell(
                  onTap: () {},
                  child: getSearchFigmaWidget(
                    context,
                    edtController,
                    () {
                      showCustomDialog();
                    },
                    (value) {},
                  ),
                )),
            getVerSpace(FetchPixels.getPixelWidth(10)),
            GridView.count(
              padding: edgeInsets,
              crossAxisCount: totalCountCat,
              childAspectRatio: gridWidth / gridHeight,
              shrinkWrap: true,
              mainAxisSpacing: defSpace,
              crossAxisSpacing: defSpace,
              // mainAxisSpacing: FetchPixels.getPixelWidth(20),
              // crossAxisSpacing: FetchPixels.getPixelWidth(20),
              primary: false,
              children: List.generate(catList.length, (index1) {
                ModelCategory catModel = catList[index1];
                return Center(
                  child: InkWell(
                    onTap: () {
                      Constant.sendToDetail(context,catModel.title,catModel.image,catModel.color);

                      // Constant.sendToNext(
                      //     context, Routes.subListCategoryPath);
                    },
                    child: SizedBox(
                      height: gridHeight,
                      child: Column(
                        children: [
                          Expanded(
                            flex: 1,
                            child: Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: FetchPixels.getPixelWidth(22),
                                  vertical: FetchPixels.getPixelWidth(22)),
                              width: FetchPixels.getPixelWidth(177),
                              height: double.infinity,
                              decoration: getButtonDecoration(
                                  catModel.color.toColor(),
                                  withCorners: true,
                                  corner: FetchPixels.getPixelHeight(15)),
                              child: Center(
                                child: Hero(
                                  tag: catModel.image,
                                  child: getAssetImage(context, catModel.image,
                                      double.infinity, double.infinity,
                                      boxFit: BoxFit.contain),
                                ),
                              ),
                            ),
                          ),
                          getVerSpace(FetchPixels.getPixelHeight(10)),
                          getCustomFont(catModel.title, 16,
                              getFontBlackColor(context), 1,
                              fontWeight: FontWeight.w700,
                              textAlign: TextAlign.center,
                              horFactor: true)
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
            getVerSpace(FetchPixels.getPixelWidth(10)),
          ],
        );
  }

  showCustomDialog() {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 1007);

    String dropdownValue = 'One';
    String dropdownValue2 = 'Product Type';

    List<String> spinnerItems = ['One', 'Two', 'Three', 'Four', 'Five'];

    List<String> spinnerItems2 = ['Product Type', 'Two', 'Three'];

    SfRangeValues values = const SfRangeValues(40.0, 80.0);

    double radius = FetchPixels.getPixelHeight(40);
    double horPadding = FetchPixels.getDefaultHorSpaceFigma(context);
    showModalBottomSheet(
        isScrollControlled: true,
        context: context,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(radius),
                topRight: Radius.circular(radius))),
        builder: (BuildContext context) {
          return SingleChildScrollView(child: StatefulBuilder(
            builder: (context, setState) {
              return Container(
                  padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).viewInsets.bottom,
                      left: horPadding,
                      right: horPadding),
                  child: Form(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        getVerSpace(FetchPixels.getPixelHeight(30)),
                        Row(
                          children: [
                            getCustomFont(
                                "Sort By", 20, getFontColor(context), 1,
                                fontWeight: FontWeight.w700),
                            Expanded(
                              flex: 1,
                              child: getHorSpace(0),
                            ),
                            getToolbarIconsCustom(context, "Close.svg", () {
                              Constant.backToPrev(context);
                            })
                          ],
                        ),
                        getVerSpace(FetchPixels.getPixelHeight(24)),
                        getCustomFont(
                            "Price Range", 16, getFontColor(context), 1,
                            fontWeight: FontWeight.w700),

//                         FlutterSlider(
//                           values: [1000, 15000],
//                           rangeSlider: true,
//
// //rtl: true,
//                           ignoreSteps: [
//                             FlutterSliderIgnoreSteps(from: 8000, to: 12000),
//                             FlutterSliderIgnoreSteps(from: 18000, to: 22000),
//                           ],
//                           max: 25000,
//                           min: 0,
//                           step: FlutterSliderStep(step: 100),
//
//                           jump: true,
//
//                           trackBar: FlutterSliderTrackBar(
//                             activeTrackBarHeight: 2,
//                             activeTrackBar: BoxDecoration(color: Colors.brown),
//                           ),
//                           tooltip: FlutterSliderTooltip(
//                             textStyle: TextStyle(fontSize: 17, color: Colors.lightBlue),
//                           ),
//                           handler: FlutterSliderHandler(
//                             decoration: BoxDecoration(),
//                             child: Container(
//                               decoration: BoxDecoration(
//                                   color: Colors.brown,
//                                   borderRadius: BorderRadius.circular(25)),
//                               padding: EdgeInsets.all(10),
//                               child: Container(
//                                 padding: EdgeInsets.all(5),
//                                 decoration: BoxDecoration(
//                                     color: Colors.white,
//                                     borderRadius: BorderRadius.circular(25)),
//                               ),
//                             ),
//                           ),
//                           rightHandler: FlutterSliderHandler(
//                             decoration: BoxDecoration(),
//                             child: Container(
//                               decoration: BoxDecoration(
//                                   color: Colors.brown,
//                                   borderRadius: BorderRadius.circular(25)),
//                               padding: EdgeInsets.all(10),
//                               child: Container(
//                                 padding: EdgeInsets.all(5),
//                                 decoration: BoxDecoration(
//                                     color: Colors.white,
//                                     borderRadius: BorderRadius.circular(25)),
//                               ),
//                             ),
//                           ),
//                           disabled: false,
//
//                           onDragging: (handlerIndex, lowerValue, upperValue) {
//                             _lowerValue = lowerValue;
//                             _upperValue = upperValue;
//                             setState(() {});
//                           },
//                         ),
                        getVerSpace(FetchPixels.getPixelHeight(50)),
                        getMediaQueryWidget(
                            context,
                            SfRangeSliderTheme(
                                data: SfRangeSliderThemeData(
                                  thumbRadius: 8,
                                  thumbStrokeWidth: 3,
                                  thumbStrokeColor: getAccentColor(context),
                                  thumbColor: Colors.white,
                                  activeTrackColor: getAccentColor(context),
                                  activeTrackHeight: 2,
                                  inactiveTrackHeight: 2,
                                  overlayRadius: 0,
                                  tooltipBackgroundColor: Colors.transparent,
                                  tooltipTextStyle: TextStyle(
                                      color: getFontColor(context),
                                      fontWeight: FontWeight.w500),
                                  inactiveTrackColor:
                                      getAccentColor(context).withOpacity(0.1),
                                ),
                                child: SfRangeSlider(
                                  tooltipTextFormatterCallback:
                                      (actualValue, formattedText) {
                                    return "\$$formattedText";
                                  },
                                  onChanged: (value) {
                                    setState(() {
                                      values = value;
                                    });
                                  },
                                  min: 10.0,
                                  tooltipShape: CustomRectangularTooltipShape(),
                                  max: 100.0,
                                  values: values,
                                  shouldAlwaysShowTooltip: true,
                                  enableTooltip: true,
                                  showLabels: false,
                                ))),
                        getVerSpace(FetchPixels.getPixelHeight(30)),
                        getCustomFont("Quantity", 16, getFontColor(context), 1,
                            fontWeight: FontWeight.w700),
                        getVerSpace(FetchPixels.getPixelHeight(12)),
                        getTextFieldViewCustom(
                            context,
                            InkWell(
                              onTap: () {},
                              child: Center(
                                child: DropdownButton(
                                  onChanged: (value) {
                                    setState(() {
                                      dropdownValue = value.toString();
                                    });

                                    // setState(() {
                                    //   dropdownValue = value;
                                    // });
                                  },
                                  value: dropdownValue,
                                  icon: getToolbarIconsCustom(
                                      context, "arrow_bottom.svg", () {}),
                                  // iconSize: 24,
                                  isExpanded: true,
                                  elevation: 0,
                                  style: TextStyle(
                                      color: getFontColor(context),
                                      fontSize: 17,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: Constant.fontsFamily),
                                  underline: Container(
                                    height: 0,
                                    color: Colors.transparent,
                                  ),
                                  items: spinnerItems
                                      .map<DropdownMenuItem<String>>(
                                          (String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: getCustomFont(
                                          value, 17, getFontColor(context), 1,
                                          fontWeight: FontWeight.w500),
                                    );
                                  }).toList(),
                                ),
                              ),
                            ),
                            false,
                            EdgeInsets.zero),
                        getVerSpace(FetchPixels.getPixelHeight(20)),
                        getTextFieldViewCustom(
                            context,
                            InkWell(
                              onTap: () {},
                              child: Center(
                                child: DropdownButton(
                                  onChanged: (value) {
                                    setState(() {
                                      dropdownValue2 = value.toString();
                                    });
                                  },
                                  value: dropdownValue2,
                                  icon: getToolbarIconsCustom(
                                      context, "arrow_bottom.svg", () {}),
                                  // iconSize: 24,
                                  isExpanded: true,
                                  elevation: 0,
                                  style: TextStyle(
                                      color: getFontColor(context),
                                      fontSize: 17,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: Constant.fontsFamily),
                                  underline: Container(
                                    height: 0,
                                    color: Colors.transparent,
                                  ),
                                  items: spinnerItems2
                                      .map<DropdownMenuItem<String>>(
                                          (String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: getCustomFont(
                                          value, 17, getFontColor(context), 1,
                                          fontWeight: FontWeight.w500),
                                    );
                                  }).toList(),
                                ),
                              ),
                            ),
                            false,
                            EdgeInsets.zero),
                        getVerSpace(FetchPixels.getPixelHeight(30)),

                        Row(
                          children: [
                            // SizedBox(width: FetchPixels.getPixelWidth(70)),
                            Expanded(
                                flex: 1,
                                child: getButtonFigma(
                                    context,
                                    Colors.transparent,
                                    true,
                                    "Reset",
                                    getAccentColor(context),
                                    () {},
                                    EdgeInsets.zero,
                                    isBorder: true,
                                    borderColor: getAccentColor(context),
                                    withGradient: false)),
                            SizedBox(width: FetchPixels.getPixelWidth(20)),
                            Expanded(
                                flex: 1,
                                child: getButtonFigma(
                                    context,
                                    Colors.transparent,
                                    true,
                                    "Apply",
                                    Colors.white, () {
                                  Constant.backToPrev(context);
                                }, EdgeInsets.zero,
                                    isBorder: false, withGradient: true)),
                            // SizedBox(width: FetchPixels.getPixelWidth(70)),
                          ],
                        ),
                        getVerSpace(FetchPixels.getPixelHeight(20)),
                      ],
                    ),
                  ));
            },
          )); // From with TextField inside
        });
  }
}

class CustomRectangularTooltipShape extends SfTooltipShape {
  /// Creates a [SfRectangularTooltipShape].
  ///
  /// A class which is used to render rectangular shape tooltip.
  CustomRectangularTooltipShape();

  bool _hasTooltipOverlapStroke() {
    return false;
  }

  // bool _hasTooltipOverlapStroke(RenderBaseSlider parentBox) {
  //   return parentBox.showOverlappingTooltipStroke;
  // }

  bool _isVertical() {
    return false;
  }

  //
  // bool _isVertical(RenderBaseSlider parentBox) {
  //   return parentBox.sliderType == SliderType.vertical;
  // }

  bool _isLeftTooltip() {
    return false;
  }

  // bool _isLeftTooltip(RenderBaseSlider parentBox) {
  //   return parentBox.tooltipPosition == SliderTooltipPosition.left;
  // }

  Path _updateRectangularTooltipWidth(
      Size textSize, double tooltipStartY, Rect trackRect, double dx,
      {required bool isVertical, bool? isLeftTooltip}) {
    final double dy = tooltipStartY + tooltipTriangleHeight;
    final double tooltipWidth =
        textSize.width < minTooltipWidth ? minTooltipWidth : textSize.width;
    final double tooltipHeight =
        textSize.height < minTooltipHeight ? minTooltipHeight : textSize.height;
    final double halfTooltipWidth = tooltipWidth / 2;
    final double halfTooltipHeight = tooltipHeight / 2;
    double halfTooltipTriangleWidth = tooltipTriangleWidth / 2;
    if (isVertical) {
      if (isLeftTooltip!) {
        double topLineHeight = dx - halfTooltipHeight < trackRect.top
            ? dx - trackRect.top
            : halfTooltipHeight;
        final double bottomLineHeight =
            dx + halfTooltipHeight > trackRect.bottom
                ? trackRect.bottom - dx
                : tooltipHeight - topLineHeight;
        topLineHeight = bottomLineHeight < halfTooltipHeight
            ? halfTooltipHeight - bottomLineHeight + topLineHeight
            : topLineHeight;
        return _getRectangularPath(tooltipStartY, topLineHeight,
            halfTooltipTriangleWidth, dy, tooltipHeight, bottomLineHeight,
            isVertical: isVertical,
            toolTipWidth: tooltipWidth,
            isLeftTooltip: isLeftTooltip);
      } else {
        double topLineHeight = dx - halfTooltipHeight < trackRect.top
            ? dx - trackRect.top
            : halfTooltipHeight;
        final double bottomLineHeight =
            dx + halfTooltipHeight > trackRect.bottom
                ? trackRect.bottom - dx
                : tooltipHeight - topLineHeight;
        topLineHeight = bottomLineHeight < halfTooltipHeight
            ? halfTooltipHeight - bottomLineHeight + topLineHeight
            : topLineHeight;
        return _getRectangularPath(tooltipStartY, topLineHeight,
            halfTooltipTriangleWidth, dy, tooltipHeight, bottomLineHeight,
            isVertical: isVertical,
            toolTipWidth: tooltipWidth,
            isLeftTooltip: isLeftTooltip);
      }
    } else {
      double rightLineWidth = dx + halfTooltipWidth > trackRect.right
          ? trackRect.right - dx
          : halfTooltipWidth;
      final double leftLineWidth = isVertical
          ? tooltipWidth - rightLineWidth
          : dx - halfTooltipWidth < trackRect.left
              ? dx - trackRect.left
              : tooltipWidth - rightLineWidth;
      if (!isVertical) {
        rightLineWidth = leftLineWidth < halfTooltipWidth
            ? halfTooltipWidth - leftLineWidth + rightLineWidth
            : rightLineWidth;
      }
      return _getRectangularPath(tooltipStartY, rightLineWidth,
          halfTooltipTriangleWidth, dy, tooltipHeight, leftLineWidth,
          isVertical: isVertical);
    }
  }

  Path _getRectangularPath(
      double tooltipStartY,
      double rightLineWidth,
      double halfTooltipTriangleWidth,
      double dy,
      double tooltipHeight,
      double leftLineWidth,
      {required bool isVertical,
      double? toolTipWidth,
      bool? isLeftTooltip}) {
    final Path path = Path();
    if (isVertical && toolTipWidth != null) {
      if (isLeftTooltip!) {
        path.moveTo(-tooltipStartY, 0);
        //     /
        final bool canAdjustTooltipNose =
            rightLineWidth < halfTooltipTriangleWidth;
        path.lineTo(-dy,
            canAdjustTooltipNose ? -rightLineWidth : -halfTooltipTriangleWidth);
        //       /
        //     |
        if (!canAdjustTooltipNose) {
          path.lineTo(-dy, -rightLineWidth + cornerRadius / 2);
        }
        path.quadraticBezierTo(
            -dy,
            canAdjustTooltipNose
                ? -rightLineWidth
                : -rightLineWidth + cornerRadius / 2,
            -dy - cornerRadius / 2,
            -rightLineWidth);
        //            /
        // __________|

        path.lineTo(-dy - toolTipWidth + cornerRadius / 2, -rightLineWidth);
        path.quadraticBezierTo(
            -dy - toolTipWidth + cornerRadius / 2,
            -rightLineWidth,
            -dy - toolTipWidth,
            -rightLineWidth + cornerRadius / 2);
        // |
        // |           /
        // |__________|
        path.lineTo(-dy - toolTipWidth, leftLineWidth - cornerRadius / 2);
        path.quadraticBezierTo(
          -dy - toolTipWidth,
          leftLineWidth - cornerRadius / 2,
          -dy - toolTipWidth + cornerRadius / 2,
          leftLineWidth,
        );
        //  _________
        // /
        // |
        // |            /
        // |__________|
        path.lineTo(-dy - cornerRadius / 2, leftLineWidth);
        //  __________
        // |          |
        // |
        // |           /
        // |__________|
        if (leftLineWidth > halfTooltipTriangleWidth) {
          path.quadraticBezierTo(-dy - cornerRadius / 2, leftLineWidth, -dy,
              leftLineWidth - cornerRadius / 2);
          path.lineTo(-dy, halfTooltipTriangleWidth);
        }
        //  __________
        // |          |
        // |           \
        // |           /
        // |__________|

        path.close();
      } else {
        path.moveTo(tooltipStartY, 0);
        //       \
        final bool canAdjustTooltipNose =
            rightLineWidth < halfTooltipTriangleWidth;
        path.lineTo(dy,
            canAdjustTooltipNose ? -rightLineWidth : -halfTooltipTriangleWidth);
        //       \
        //        |
        if (!canAdjustTooltipNose) {
          path.lineTo(dy, -rightLineWidth + cornerRadius / 2);
        }
        //        \
        //         |__________
        path.quadraticBezierTo(
            dy,
            canAdjustTooltipNose
                ? -rightLineWidth
                : -rightLineWidth + cornerRadius / 2,
            dy + cornerRadius / 2,
            -rightLineWidth);
        path.lineTo(dy + toolTipWidth - cornerRadius / 2, -rightLineWidth);
        //                    |
        //        \           |
        //         |__________|
        path.quadraticBezierTo(
            dy + toolTipWidth - cornerRadius / 2,
            -rightLineWidth,
            dy + toolTipWidth,
            -rightLineWidth + cornerRadius / 2);
        path.lineTo(dy + toolTipWidth, leftLineWidth - cornerRadius / 2);
        //         ___________
        //                    |
        //                    |
        //        \           |
        //         |__________|
        path.quadraticBezierTo(
          dy + toolTipWidth,
          leftLineWidth - cornerRadius / 2,
          dy + toolTipWidth - cornerRadius / 2,
          leftLineWidth,
        );
        path.lineTo(dy + cornerRadius / 2, leftLineWidth);
        //         ___________
        //        |           |
        //                    |
        //      \             |
        //        |__________|
        if (leftLineWidth > halfTooltipTriangleWidth) {
          path.quadraticBezierTo(dy + cornerRadius / 2, leftLineWidth, dy,
              leftLineWidth - cornerRadius / 2);
          path.lineTo(dy, halfTooltipTriangleWidth);
        }
        //         ___________
        //        |           |
        //      |             |
        //      \             |
        //        |__________|
        path.close();
      }
    } else {
      path.moveTo(0, -tooltipStartY);
      //    /
      final bool canAdjustTooltipNose =
          rightLineWidth > halfTooltipTriangleWidth + cornerRadius / 2;
      path.lineTo(
          canAdjustTooltipNose ? halfTooltipTriangleWidth : rightLineWidth,
          -dy - (canAdjustTooltipNose ? 0 : cornerRadius / 2));
      //      ___
      //     /
      path.lineTo(rightLineWidth - cornerRadius, -dy);
      //      ___|
      //     /
      path.quadraticBezierTo(
          rightLineWidth, -dy, rightLineWidth, -dy - cornerRadius);
      path.lineTo(rightLineWidth, -dy - tooltipHeight + cornerRadius);
      //  _______
      //      ___|
      //     /
      path.quadraticBezierTo(rightLineWidth, -dy - tooltipHeight,
          rightLineWidth - cornerRadius, -dy - tooltipHeight);
      path.lineTo(-leftLineWidth + cornerRadius, -dy - tooltipHeight);
      //  _______
      // |    ___|
      //     /
      path.quadraticBezierTo(-leftLineWidth, -dy - tooltipHeight,
          -leftLineWidth, -dy - tooltipHeight + cornerRadius);
      path.lineTo(-leftLineWidth, -dy - cornerRadius);
      //  ________
      // |___  ___|
      //      /
      if (leftLineWidth > halfTooltipTriangleWidth) {
        path.quadraticBezierTo(
            -leftLineWidth, -dy, -leftLineWidth + cornerRadius, -dy);
        path.lineTo(-halfTooltipTriangleWidth, -dy);
      }
      //  ________
      // |___  ___|
      //     \/
      path.close();
    }
    return path;
  }

  double tooltipTriangleHeight = 0;
  double tooltipTriangleWidth = 0;
  double cornerRadius = 0.0;
  Offset tooltipTextPadding = const Offset(2, 2);
  double minTooltipWidth = 10.0;
  double minTooltipHeight = 10;

  /// Draws the tooltip based on the values passed in the arguments.
  @override
  void paint(PaintingContext context, Offset thumbCenter, Offset offset,
      TextPainter textPainter,
      {required RenderBox parentBox,
      required SfSliderThemeData sliderThemeData,
      required Paint paint,
      required Animation<double> animation,
      required Rect trackRect}) {
    final double leftPadding = tooltipTextPadding.dx / 2;
    final double minLeftX = trackRect.left;
    // ignore: avoid_as
    final Path path = (_isVertical())
        ? _updateRectangularTooltipWidth(textPainter.size + tooltipTextPadding,
            offset.dy, trackRect, thumbCenter.dy,
            isVertical: _isVertical(), isLeftTooltip: _isLeftTooltip())
        : _updateRectangularTooltipWidth(textPainter.size + tooltipTextPadding,
            offset.dy, trackRect, thumbCenter.dx,
            isVertical: _isVertical());

    context.canvas.save();
    context.canvas.translate(thumbCenter.dx, thumbCenter.dy);
    context.canvas.scale(animation.value);
    final Paint strokePaint = Paint();
    if (_hasTooltipOverlapStroke() &&
        sliderThemeData.tooltipBackgroundColor != Colors.transparent) {
      if (sliderThemeData is SfRangeSliderThemeData) {
        strokePaint.color = sliderThemeData.overlappingTooltipStrokeColor!;
        strokePaint.style = PaintingStyle.stroke;
        strokePaint.strokeWidth = 1.0;
      } else if (sliderThemeData is SfRangeSelectorThemeData) {
        strokePaint.color = sliderThemeData.overlappingTooltipStrokeColor!;
        strokePaint.style = PaintingStyle.stroke;
        strokePaint.strokeWidth = 1.0;
      }
    }
    // This loop is used to avoid the improper rendering of tooltips in
    // web html rendering.
    else {
      strokePaint
        ..color = Colors.transparent
        ..style = PaintingStyle.stroke;
    }
    context.canvas.drawPath(path, strokePaint);
    context.canvas.drawPath(path, paint);

    final Rect pathRect = path.getBounds();
    final double halfPathWidth = pathRect.width / 2;
    final double halfTextPainterWidth = textPainter.width / 2;
    final double rectLeftPosition = thumbCenter.dx - halfPathWidth;
    if (_isVertical()) {
      final double halfPathHeight = pathRect.height / 2;
      final double halfTextPainterHeight = textPainter.height / 2;
      final double rectTopPosition = thumbCenter.dy - halfPathHeight;
      if (_isLeftTooltip()) {
        final double dx = -offset.dy -
            tooltipTriangleHeight -
            (pathRect.size.width - tooltipTriangleHeight) / 2 -
            textPainter.width / 2;
        final double dy = rectTopPosition >= trackRect.top
            ? thumbCenter.dy + halfPathHeight >= trackRect.bottom
                ? -halfTextPainterHeight -
                    halfPathHeight -
                    thumbCenter.dy +
                    trackRect.bottom
                : -halfTextPainterHeight
            : -halfTextPainterHeight +
                halfPathHeight -
                thumbCenter.dy +
                trackRect.top;
        textPainter.paint(context.canvas, Offset(dx, dy));
      } else {
        final double dx = offset.dy +
            tooltipTriangleHeight +
            (pathRect.size.width - tooltipTriangleHeight) / 2 -
            textPainter.width / 2;
        final double dy = rectTopPosition >= trackRect.top
            ? thumbCenter.dy + halfPathHeight >= trackRect.bottom
                ? -halfTextPainterHeight -
                    halfPathHeight -
                    thumbCenter.dy +
                    trackRect.bottom
                : -halfTextPainterHeight
            : -halfTextPainterHeight +
                halfPathHeight -
                thumbCenter.dy +
                trackRect.top;
        textPainter.paint(context.canvas, Offset(dx, dy));
      }
    } else {
      final double dx = rectLeftPosition >= minLeftX
          ? thumbCenter.dx + halfTextPainterWidth + leftPadding >
                  trackRect.right
              ? -halfTextPainterWidth -
                  halfPathWidth +
                  trackRect.right -
                  thumbCenter.dx
              : -halfTextPainterWidth
          : -halfTextPainterWidth +
              halfPathWidth +
              trackRect.left -
              thumbCenter.dx;
      final double dy = offset.dy +
          tooltipTriangleHeight +
          (pathRect.size.height - tooltipTriangleHeight) / 2 +
          textPainter.height / 2;
      textPainter.paint(context.canvas, Offset(dx, -dy));
    }
    context.canvas.restore();
  }
// }  // @override
// void paint(PaintingContext context, Offset offset, Offset? thumbCenter,
//     Offset? startThumbCenter, Offset? endThumbCenter,
//     {required RenderBox parentBox,
//       required SfSliderThemeData themeData,
//       SfRangeValues? currentValues,
//       dynamic currentValue,
//       required Animation<double> enableAnimation,
//       required Paint? inactivePaint,
//       required Paint? activePaint,
//       required TextDirection textDirection}) {
//   Paint paint = Paint()
//     ..color = themeData.activeTrackColor!
//     ..style = PaintingStyle.stroke
//     ..strokeWidth = 1;
//   super.paint(context, offset, thumbCenter, startThumbCenter, endThumbCenter,
//       parentBox: parentBox,
//       themeData: themeData,
//       enableAnimation: enableAnimation,
//       inactivePaint: inactivePaint,
//       activePaint: paint,
//       textDirection: textDirection);
// }
}
