// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:grocery/base/color_data.dart';
import 'package:grocery/base/constant.dart';
import 'package:grocery/base/resizer/fetch_pixels.dart';
import 'package:grocery/base/widget_utils.dart';

import '../../data/data_file.dart';
import '../../models/model_category.dart';

class CategorySubListScreen extends StatefulWidget {
  const CategorySubListScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _CategorySubListScreen();
  }
}

class _CategorySubListScreen extends State<CategorySubListScreen> {
  TextEditingController edtController = TextEditingController();
  List<ModelCategory> catList = DataFile.getAllSubCategoryList();

  backClick() {
    Constant.backToPrev(context);
  }

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 1007);
    double defSpace = FetchPixels.getDefaultHorSpaceFigma(context);
    EdgeInsets edgeInsets = EdgeInsets.symmetric(horizontal: defSpace);
    int totalCountCat = 3;
    double width = MediaQuery.of(context).size.width;
    double gridWidthSet = (width) / totalCountCat;
    double gridWidth = FetchPixels.getPixelWidth(112);
    double gridHeight = FetchPixels.getPixelWidth(142);

    return WillPopScope(
      onWillPop: () async {
        backClick();
        return false;
      },
      child: Scaffold(
        body: SizedBox(
          width: double.infinity,
          height: double.infinity,
          child: buildListView(context, edgeInsets, totalCountCat, gridWidthSet,
              gridHeight, defSpace, gridWidth),
        ),
        backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
        appBar: getInVisibleAppBar(),
      ),
    );
  }

  ListView buildListView(
      BuildContext context,
      EdgeInsets edgeInsets,
      int totalCountCat,
      double gridWidthSet,
      double gridHeight,
      double defSpace,
      double gridWidth) {
    return ListView(
      primary: true,
      shrinkWrap: true,
      padding: EdgeInsets.zero,
      children: [
        getToolbarFigmaWidget(context, "Categories", () {
          backClick();
        }, withBack: true, settingVisible: false),
        getPaddingWidget(
            edgeInsets,
            InkWell(
              onTap: () {},
              child: IgnorePointer(
                ignoring: true,
                child: getSearchFigmaWidget(
                  context,
                  edtController,
                  () {},
                  (value) {},
                ),
              ),
            )),
        getVerSpace(FetchPixels.getPixelWidth(10)),
        AnimationLimiter(
            child: GridView.count(
          padding: edgeInsets,
          crossAxisCount: totalCountCat,
          childAspectRatio: gridWidthSet / gridHeight,
          shrinkWrap: true,
          mainAxisSpacing: defSpace,
          crossAxisSpacing: defSpace,
          // mainAxisSpacing: FetchPixels.getPixelWidth(20),
          // crossAxisSpacing: FetchPixels.getPixelWidth(20),
          primary: false,
          children: List.generate(catList.length, (index1) {
            ModelCategory catModel = catList[index1];
            return AnimationConfiguration.staggeredGrid(
                position: index1,
                columnCount: totalCountCat,
                child: ScaleAnimation(
                  child: FadeInAnimation(
                    duration: const Duration(milliseconds: 500),
                    child: Center(
                      child: InkWell(
                        onTap: () {
                          Constant.sendToDetail(context, catModel.title,
                              catModel.image, catModel.color,
                              heroKey1: catModel.title);
                          // Constant.sendToNext(context, Routes.detailScreenPath);
                        },
                        child: Container(
                          width: gridWidth,
                          height: gridHeight,
                          padding: EdgeInsets.all(FetchPixels.getPixelWidth(10)),
                          decoration: getButtonDecoration(Colors.white,
                              withCorners: true,
                              corner: FetchPixels.getPixelWidth(12),
                              shadow: [
                                BoxShadow(
                                    color: Colors.black.withOpacity(0.05),
                                    offset: const Offset(-5, 6),
                                    blurRadius: 28)
                              ]),
                          child: Column(
                            children: [
                              Expanded(
                                flex: 1,
                                child: Container(
                                  padding:
                                  EdgeInsets.all(FetchPixels.getPixelWidth(8)),
                                  width: double.infinity,
                                  height: double.infinity,
                                  decoration: getButtonDecoration(
                                      catModel.color.toColor(),
                                      withCorners: true,
                                      corner: FetchPixels.getPixelWidth(12)),
                                  child: Center(
                                    child: Hero(
                                      tag: catModel.title,
                                      child: getAssetImage(context, catModel.image,
                                          double.infinity, double.infinity,
                                          boxFit: BoxFit.contain),
                                    ),
                                  ),
                                ),
                              ),
                              getVerSpace(FetchPixels.getPixelWidth(10)),
                              getCustomFont(
                                  catModel.title, 14, getFontBlackColor(context), 1,
                                  fontWeight: FontWeight.w700,
                                  textAlign: TextAlign.center,
                                  horFactor: true)
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ));
          }),
        )),
        getVerSpace(FetchPixels.getPixelWidth(10)),
      ],
    );
  }
}
