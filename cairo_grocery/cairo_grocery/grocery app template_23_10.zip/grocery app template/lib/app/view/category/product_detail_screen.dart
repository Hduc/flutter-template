// ignore_for_file: deprecated_member_use

import 'package:figma_squircle/figma_squircle.dart';
import 'package:flutter/material.dart';
import 'package:grocery/app/routes/app_routes.dart';
import 'package:grocery/base/color_data.dart';
import 'package:grocery/base/constant.dart';
import 'package:grocery/base/resizer/fetch_pixels.dart';
import 'package:grocery/base/widget_utils.dart';

class ProductDetailScreen extends StatefulWidget {
  //
  // ProductDetailScreen(this.name, this.image,
  //     {this.bgColor});
  const ProductDetailScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _ProductDetailScreen();
  }
}

class _ProductDetailScreen extends State<ProductDetailScreen> {
  backClick() {
    Constant.backToPrev(context);
  }

  String? name;
  String? image;
  String? bgColor;
  String? heroKey;

  @override
  void initState() {
    Future.delayed(
      Duration.zero,
      () {
        final arg = ModalRoute.of(context)!.settings.arguments as Map?;
        if (arg != null) {
          setState(() {
            name = arg[Constant.nameSend];
            image = arg[Constant.imageSend];
            bgColor = arg[Constant.bgColor];
            heroKey = arg[Constant.heroKey];
          });
        }
      },
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 1007);
    double horPadding = FetchPixels.getDefaultHorSpaceFigma(context);
    EdgeInsets edgeInsets = EdgeInsets.symmetric(horizontal: horPadding);

    SmoothRadius radius = SmoothRadius(cornerRadius: FetchPixels.getPixelWidth(40), cornerSmoothing: 0.8);
    Color setColor = defBgColor;
    // Color setColor = (bgColor == null || bgColor!.isEmpty) ? defBgColor : bgColor!.toColor();
    return WillPopScope(
        child: Scaffold(
          appBar: getInVisibleAppBar(color: setColor),
          backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
          body: Stack(
            children: [
              buildContainer(radius, setColor),
              buildSizedBox(edgeInsets, context, horPadding)
            ],
          ),
        ),
        onWillPop: () async {
          backClick();
          return false;
        });
  }

  SizedBox buildSizedBox(
      EdgeInsets edgeInsets, BuildContext context, double horPadding) {
    String keySet= (heroKey==null || heroKey!.isEmpty)?(image??"1"):heroKey!;
    return SizedBox(
      height: double.infinity,
      width: double.infinity,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          getVerSpace(FetchPixels.getPixelHeight(15)),
          getPaddingWidget(
              edgeInsets,
              getToolbarIconsCustom(context, "arrow_back.svg", () {
                backClick();
              })),
          Center(
              child: Hero(
                tag: keySet,
                child: getAssetImage(
                    context,
                    image ?? "sub1.png",
                    FetchPixels.getPixelHeight(269),
                    FetchPixels.getPixelHeight(254),
                    boxFit: BoxFit.contain),
              )),
          Expanded(
            flex: 1,
            child: Container(
              width: double.infinity,
              height: double.infinity,
              margin: EdgeInsets.only(
                  left: horPadding,
                  right: horPadding,
                  top: FetchPixels.getPixelHeight(35),
                  bottom: FetchPixels.getPixelHeight(39)),
              decoration: getButtonDecoration(Colors.white,
                  withCorners: true,
                  corner: FetchPixels.getPixelWidth(20),
                  shadow: [
                    const BoxShadow(
                        color:
                            Color.fromRGBO(155, 103, 103, 0.10999999940395355),
                        offset: Offset(-5, 6),
                        blurRadius: 28)
                  ]),
              child: Column(
                children: [
                  Expanded(
                    flex: 1,
                    child: ListView(
                      physics: const BouncingScrollPhysics(),
                      shrinkWrap: true,
                      primary: true,
                      padding: EdgeInsets.symmetric(
                          vertical: FetchPixels.getPixelHeight(20),
                          horizontal: FetchPixels.getPixelWidth(20)),
                      children: [
                        getCustomFont(name ?? "", 28, getFontColor(context), 1,
                            fontWeight: FontWeight.w700),
                        getVerSpace(FetchPixels.getPixelHeight(14)),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            getCustomFont("\$", 14, getAccentColor(context), 1,
                                fontWeight: FontWeight.w700),
                            getCustomFont("5.20", 16, getFontColor(context), 1,
                                fontWeight: FontWeight.w700),
                            getHorSpace(FetchPixels.getPixelWidth(8)),
                            Container(
                              width: FetchPixels.getPixelHeight(71),
                              height: FetchPixels.getPixelHeight(28),
                              decoration: getButtonDecoration(
                                "#FFF3F3".toColor(),
                                corner: FetchPixels.getPixelHeight(12),
                                withCorners: true,
                              ),
                              child: Center(
                                child: getCustomFont(
                                    "Per KG", 14, getAccentColor(context), 1,
                                    fontWeight: FontWeight.w500,
                                    textAlign: TextAlign.center),
                              ),
                            )
                          ],
                        ),
                        getVerSpace(FetchPixels.getPixelHeight(33)),
                        Row(
                          children: [
                            getSvgImageWithSize(
                                context,
                                "star.svg",
                                FetchPixels.getPixelHeight(18),
                                FetchPixels.getPixelHeight(18)),
                            getHorSpace(FetchPixels.getPixelWidth(11)),
                            getCustomFont("4.2", 14, getFontColor(context), 1,
                                fontWeight: FontWeight.w700),
                            getCustomFont(
                                " (425)", 14, getFontColor(context), 1,
                                fontWeight: FontWeight.w500),
                            Expanded(
                              flex: 1,
                              child: getHorSpace(0),
                            ),
                            getButtonContainer(context, Icons.add, () {}),
                            getHorSpace(FetchPixels.getPixelWidth(13)),
                            getCustomFont("1 kg", 14, getFontColor(context), 1,
                                fontWeight: FontWeight.w700),
                            getHorSpace(FetchPixels.getPixelWidth(13)),
                            getButtonContainer(context, Icons.remove, () {}),
                          ],
                        ),
                        getVerSpace(FetchPixels.getPixelHeight(32)),
                        getCustomFont("Detail", 16, getFontColor(context), 1,
                            fontWeight: FontWeight.w700),
                        getVerSpace(FetchPixels.getPixelHeight(10)),
                        getMultilineCustomFont(
                            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
                            16,
                            getFontColor(context),
                            fontWeight: FontWeight.w500,
                            txtHeight: 1.5)
                      ],
                    ),
                  ),
                  getButtonFigma(context, Colors.transparent, true,
                      "Add to Cart", Colors.white, () {
                    Constant.sendToNext(context, Routes.homeScreenRoute,
                        arguments: {Constant.homePos: 1});
                  },
                      EdgeInsets.symmetric(
                          horizontal: FetchPixels.getPixelWidth(20),
                          vertical: FetchPixels.getPixelHeight(20)),
                      withGradient: true)
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Container buildContainer(SmoothRadius radius, Color color) {
    return Container(
      width: double.infinity,
      height: FetchPixels.getPixelHeight(412),
      decoration: ShapeDecoration(
          color: color,
          shape: SmoothRectangleBorder(
              borderRadius: SmoothBorderRadius.only(
                  bottomRight: radius, bottomLeft: radius))),
    );
  }
}
