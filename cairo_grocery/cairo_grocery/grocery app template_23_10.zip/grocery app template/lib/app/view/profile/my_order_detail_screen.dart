// ignore_for_file: deprecated_member_use

import 'package:dotted_line/dotted_line.dart';
import 'package:flutter/material.dart';
import 'package:grocery/app/data/data_file.dart';

import '../../../base/color_data.dart';
import '../../../base/constant.dart';
import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../models/model_my_order.dart';

class MyOrderDetailScreen extends StatefulWidget {
  const MyOrderDetailScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _MyOrderDetailScreen();
  }
}

class _MyOrderDetailScreen extends State<MyOrderDetailScreen> {
  void backClick() {
    Constant.backToPrev(context);
  }

  List<ModelMyOrder> myOrderList = DataFile.getMyOrders();

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 896);
    double defHorSpace = FetchPixels.getDefaultHorSpaceFigma(context);
    EdgeInsets edgeInsets = EdgeInsets.symmetric(horizontal: defHorSpace);
    ModelMyOrder modelMyOrder = DataFile.getMyOrders()[1];
    Widget dividerWidget = getPaddingWidget(
        edgeInsets,
        Divider(
          height: FetchPixels.getPixelHeight(1),
          color: dividerColor,
        ));
    return WillPopScope(
        child: Scaffold(
          backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
          appBar: getInVisibleAppBar(),
          body: buildList(context, edgeInsets, modelMyOrder, dividerWidget, defHorSpace),
        ),
        onWillPop: () async {
          backClick();
          return false;
        });
  }

  ListView buildList(BuildContext context, EdgeInsets edgeInsets, ModelMyOrder modelMyOrder, Widget dividerWidget, double defHorSpace) {
    return ListView(
          shrinkWrap: true,
          primary: true,
          children: [
            getToolbarFigmaWidget(
              context,
              "My Orders",
              () {
                backClick();
              },
              withBack: true,
              settingVisible: false,
            ),
            getVerSpace(FetchPixels.getPixelHeight(12)),
            getPaddingWidget(
                edgeInsets,
                Row(
                  children: [
                    Container(
                      width: FetchPixels.getPixelHeight(81),
                      height: FetchPixels.getPixelHeight(81),
                      padding: EdgeInsets.symmetric(
                          horizontal: FetchPixels.getPixelHeight(14),
                          vertical: FetchPixels.getPixelHeight(16)),
                      decoration: getButtonDecoration(modelMyOrder.colorBg!,
                          withCorners: true,
                          corner: FetchPixels.getPixelHeight(12)),
                      child: Center(
                        child: getAssetImage(
                            context,
                            modelMyOrder.image ?? "",
                            double.infinity,
                            double.infinity),
                      ),
                    ),
                    getHorSpace(FetchPixels.getPixelWidth(12)),
                    Expanded(
                      flex: 1,
                      child: getCustomFont(
                          "Arriving today", 16, getFontColor(context), 1,
                          fontWeight: FontWeight.w500),
                    ),
                    getCustomFont("8 PM", 16, getFontColor(context), 1,
                        fontWeight: FontWeight.w700)
                  ],
                )),
            getVerSpace(FetchPixels.getPixelHeight(32)),
            timelineRow("Ordered on Monday,January 23", "", '', true),
            timelineRow("Shipped on Monday,January 23", '', '', true),
            timelineRow("Out for delivery", 'See all updates', "", true),
            timelineRow("Arriving today by 8PM", '', "", false),
            getVerSpace(FetchPixels.getPixelHeight(26)),
            dividerWidget,
            getVerSpace(FetchPixels.getPixelHeight(23)),
            getPaddingWidget(edgeInsets, getTitles("Shipped with App Name")),
            getVerSpace(FetchPixels.getPixelHeight(13)),
            getRowWidgetDetail(
                "Request Cancellation",
                EdgeInsets.symmetric(
                    horizontal: defHorSpace,
                    vertical: FetchPixels.getPixelHeight(16)),
                () {}),
            getPaddingWidget(
                edgeInsets,
                Row(
                  children: [
                    getCustomFont("Tracking ID", 16, black40, 1,
                        fontWeight: FontWeight.w500),
                    getCustomFont(" :  546365", 16, getFontColor(context), 1,
                        fontWeight: FontWeight.w500)
                  ],
                )),
            getVerSpace(FetchPixels.getPixelHeight(20)),
            dividerWidget,
            getVerSpace(FetchPixels.getPixelHeight(20)),
            getPaddingWidget(
                edgeInsets,
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: getTitles("Shipping Address"),
                    ),
                    getCustomFont("See all updates", 15, redFontColor, 2,
                        fontWeight: FontWeight.w400)
                  ],
                )),
            getVerSpace(FetchPixels.getPixelHeight(14)),
            getPaddingWidget(edgeInsets,
                getSubTitles("1901 Thornridge Cir. Shiloh, Hawaii 81063")),
            getVerSpace(FetchPixels.getPixelHeight(20)),
            dividerWidget,
            getVerSpace(FetchPixels.getPixelHeight(20)),
            getRowWidgetDetail(
                "Return or Replace Items",
                EdgeInsets.symmetric(
                    horizontal: defHorSpace,
                    vertical: FetchPixels.getPixelHeight(16)),
                    () {}),
            getRowWidgetDetail(
                "View Order Details",
                EdgeInsets.symmetric(
                    horizontal: defHorSpace,
                    vertical: FetchPixels.getPixelHeight(16)),
                    () {}),
            getVerSpace(FetchPixels.getPixelHeight(40)),

          ],
        );
  }

  Widget getTitles(String string) {
    return getCustomFont(string, 16, getFontColor(context), 1,
        fontWeight: FontWeight.w700);
  }

  Widget getSubTitles(String string) {
    return getCustomFont(string, 16, getFontColor(context), 1,
        fontWeight: FontWeight.w500);
  }

  Widget getRowWidgetDetail(
      String title, EdgeInsets edgeInsets, Function function) {
    double size = FetchPixels.getPixelHeight(24);
    return InkWell(
      onTap: () {
        function();
      },
      child: Container(
        margin: edgeInsets,
        height: FetchPixels.getPixelHeight(60),
        width: double.infinity,
        padding:
            EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(18)),
        decoration: getButtonDecoration(Colors.white,
            corner: getButtonCornersFigma(),
            withCorners: true,
            shadow: [
              const BoxShadow(
                  color: Color.fromRGBO(155, 103, 103, 0.10999999940395355),
                  offset: Offset(-5, 6),
                  blurRadius: 28)
            ]),
        child: Row(
          children: [
            Expanded(
              flex: 1,
              child: getSubTitles(title),
            ),
            getSvgImageWithSize(context, "arrow_right.svg", size, size)
          ],
        ),
      ),
    );
  }

  Widget timelineRow(
      String title, String desc, String subTitle, bool isSelect) {
    double defMargin = FetchPixels.getDefaultHorSpaceFigma(context);
    double size = FetchPixels.getPixelHeight(24);
    double height = FetchPixels.getPixelHeight(55);
    // double height = Constant.getHeightPercentSize(7);
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        getHorSpace(defMargin),
        Expanded(
          flex: 1,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                  width: size,
                  height: size,
                  child: isSelect
                      ? getSvgImageWithSize(context, "Check.svg", size, size)
                      : getSvgImageWithSize(
                          context, "un_selected_check.svg", size, size)),
              SizedBox(
                width: FetchPixels.getPixelWidth(1),
                height: (isSelect) ? height : 0,
                child: (isSelect)
                    ? DottedLine(
                        dashLength: height / 10,
                        lineThickness: height / 10,
                        // dashRadius: 0.0,
                        dashGapLength: height / 10,
                        // dashGapLength: height/10,
                        dashColor: isSelect ? getFontColor(context) : greyFont,
                        direction: Axis.horizontal,
                        lineLength: (height),
                      )
                    : Container(),

                // decoration: new BoxDecoration(
                //   color: isSelect?(primaryColor):Colors.grey,
                //   shape: BoxShape.rectangle,
                // ),
                // child: Text(""),
              ),
            ],
          ),
        ),
        // Container(
        //   child: Column(
        //     mainAxisSize: MainAxisSize.min,
        //     crossAxisAlignment: CrossAxisAlignment.center,
        //     children: <Widget>[
        //       Container(
        //           width: size,
        //           height: size,
        //           child: isSelect
        //               ? getSvgImageWithSize(context, "Check.svg", size, size)
        //               : getSvgImageWithSize(
        //               context, "un_selected_check.svg", size, size)),
        //       Container(
        //         width: FetchPixels.getPixelWidth(1),
        //         height: (isSelect) ? height : 0,
        //         child: (isSelect)
        //             ? DottedLine(
        //           dashLength: FetchPixels.getPixelWidth(1),
        //           lineThickness: 3,
        //           dashRadius: 0.0,
        //           dashGapLength: 3.0,
        //           dashColor: isSelect ? (primaryColor) : greyFont,
        //           direction: Axis.horizontal,
        //           lineLength: (height),
        //         )
        //             : Container(),
        //
        //         // decoration: new BoxDecoration(
        //         //   color: isSelect?(primaryColor):Colors.grey,
        //         //   shape: BoxShape.rectangle,
        //         // ),
        //         // child: Text(""),
        //       ),
        //     ],
        //   ),
        // ),
        Expanded(
          // flex: 1,
          flex: 9,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                flex: 1,
                child: getCustomFont(title, 14, getFontColor(context), 1,
                    fontWeight: FontWeight.w700),
              ),
              getCustomFont(desc, 15, redFontColor, 2,
                  fontWeight: FontWeight.w400),
              // Column(
              //   crossAxisAlignment: CrossAxisAlignment.start,
              //   children: [
              //     getCustomFont(title,14,getFontColor(context),1,fontWeight: FontWeight.w700),
              //     // Text(title,
              //     //     style: TextStyle(
              //     //         fontFamily: Constant.fontsFamily,
              //     //         fontSize: 14,
              //     //         fontWeight: FontWeight.w700,
              //     //         color: getFontColor(context))),
              //     SizedBox(
              //       height: Constant.getHeightPercentSize(1),
              //     ),
              //     getCustomFont(desc, 15, getFontColor(context), 2,
              //         fontWeight: FontWeight.w400),
              //   ],
              // ),
            ],
          ),
        ),
        getHorSpace(defMargin)
      ],
    );
  }

  getRowWidget(String s, String t) {
    return Column(
      children: [
        Row(
          children: [
            SizedBox(
              width: FetchPixels.getPixelWidth(170),
              child:
                  getCustomFont(s, 14, black40, 1, fontWeight: FontWeight.w500),
            ),
            Expanded(
              flex: 1,
              child: getCustomFont(t, 14, getFontColor(context), 1,
                  fontWeight: FontWeight.w500),
            )
          ],
        ),
        Padding(
          padding: EdgeInsets.only(
              left: FetchPixels.getPixelWidth(170),
              top: FetchPixels.getPixelHeight(16),
              bottom: FetchPixels.getPixelHeight(16)),
          child: Divider(
              height: FetchPixels.getPixelHeight(1), color: Colors.black12),
        )
      ],
    );
  }
}
