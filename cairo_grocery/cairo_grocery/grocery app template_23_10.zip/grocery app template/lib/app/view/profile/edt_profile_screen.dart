// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import '../../../base/color_data.dart';
import '../../../base/constant.dart';
import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _EditProfileScreen();
  }
}

class _EditProfileScreen extends State<EditProfileScreen> {
  void backClick() {
    Constant.backToPrev(context);
  }

  TextEditingController nameCon = TextEditingController(text: "Riyana Wilson");
  TextEditingController emailCon =
      TextEditingController(text: "riyanawilson@gmail.com");
  TextEditingController numberCon =
      TextEditingController(text: "+1 (603) 555-0123");

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 896);
    double defHorSpace = FetchPixels.getDefaultHorSpaceFigma(context);
    double editSize = FetchPixels.getPixelHeight(34);
    Widget getVerWidget=getVerSpace(FetchPixels.getPixelHeight(20));
    return WillPopScope(
        child: Scaffold(
          backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
          appBar: getInVisibleAppBar(),
          body: Column(
            children: [
              buildToolbar(context),
              buildExpand(editSize, context, defHorSpace, getVerWidget),
              buildButton(context, defHorSpace)
            ],
          ),
        ),
        onWillPop: () async {
          backClick();
          return false;
        });
  }

  Widget buildButton(BuildContext context, double defHorSpace) {
    return getButtonFigma(context, Colors.transparent, true, "Save", Colors.white, () {
              backClick();
            },
                EdgeInsets.symmetric(
                    horizontal: defHorSpace,
                    vertical: FetchPixels.getPixelHeight(18)),
                withGradient: true);
  }

  Expanded buildExpand(double editSize, BuildContext context, double defHorSpace, Widget getVerWidget) {
    return Expanded(
              flex: 1,
              child: ListView(
                children: [
                  Center(
                    child: SizedBox(
                      height: FetchPixels.getPixelHeight(100),
                      width: FetchPixels.getPixelWidth(100) + (editSize / 2),
                      child: Stack(
                        children: [
                          Center(
                            child: getCircleImage(context, "profile.png",
                                FetchPixels.getPixelHeight(100)),
                          ),
                          Align(
                            alignment: Alignment.bottomRight,
                            child: Container(
                              margin: EdgeInsets.only(right: editSize / 2),
                              child: getSvgImageWithSize(context,
                                  "edit_icon.svg", editSize, editSize),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: defHorSpace),
                    child: Column(
                      children: [
                        getVerWidget,
                        getVerWidget,
                          getDefaultTextFiledFigma(
                              context, "Name", nameCon, getFontColor(context)),
                        getVerWidget,
                        getDefaultTextFiledFigma(context, "Email", emailCon,
                            getFontColor(context)),
                        getVerWidget,
                        getDefaultTextFiledFigma(context, "Phone Number",
                            numberCon, getFontColor(context)),
                        getVerWidget,
                      ],
                    ),
                  )
                ],
              ),
            );
  }

  Widget buildToolbar(BuildContext context) {
    return getToolbarFigmaWidget(
              context,
              "Edit Profile",
              () {
                backClick();
              },
              withBack: true,
              settingVisible: false,
            );
  }
}
