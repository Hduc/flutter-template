// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import '../../../base/select_state.dart';
import '../../../base/color_data.dart';
import '../../../base/constant.dart';
import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';

class AddShippingAddressScreen extends StatefulWidget {
  const AddShippingAddressScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _AddShippingAddressScreen();
  }
}

class _AddShippingAddressScreen extends State<AddShippingAddressScreen> {
  void backClick() {
    Constant.backToPrev(context);
  }

  TextEditingController txtControllerName =
      TextEditingController(text: "Jennie");
  TextEditingController txtPinCode = TextEditingController(text: "83475");
  TextEditingController txtPhoneNum =
      TextEditingController(text: "+1 (603) 555-0123");
  TextEditingController txtControllerAddress =
      TextEditingController(text: "2715 Ash Dr.San Jose, South Dakota 83475");

  String countryValue = "";
  String stateValue = "";
  String cityValue = "";

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 896);
    double defHorSpace = FetchPixels.getDefaultHorSpaceFigma(context);
    Widget verSpace = getVerSpace(FetchPixels.getPixelHeight(20));

    return WillPopScope(
        child: Scaffold(
          backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
          appBar: getInVisibleAppBar(),
          body: Column(
            children: [
              buildToolbar(context),
              getVerSpace(FetchPixels.getPixelHeight(12)),
              buildExpandView(defHorSpace, context, verSpace),
              buildFigmaButton(context, defHorSpace)
            ],
          ),
        ),
        onWillPop: () async {
          backClick();
          return false;
        });
  }

  Widget buildFigmaButton(BuildContext context, double defHorSpace) {
    return getButtonFigma(
                context, Colors.transparent, true, "Save", Colors.white, () {
              backClick();
            },
                EdgeInsets.symmetric(
                    horizontal: defHorSpace,
                    vertical: FetchPixels.getPixelHeight(20)));
  }

  Expanded buildExpandView(double defHorSpace, BuildContext context, Widget verSpace) {
    return Expanded(
              flex: 1,
              child: ListView(
                padding: EdgeInsets.symmetric(horizontal: defHorSpace),
                children: [
                  getDefaultTextFiledFigma(
                    context,
                    "Name",
                    txtControllerName,
                    getFontColor(context),
                  ),
                  verSpace,
                  getDefaultTextFiledFigma(context, "Address",
                      txtControllerAddress, getFontColor(context),
                      minLines: true),
                  verSpace,
                  getDefaultTextFiledFigma(
                    context,
                    "PinCode",
                    txtPinCode,
                    getFontColor(context),
                  ),
                  verSpace,
                  SelectState(
                    // style: TextStyle(color: Colors.red),
                    onCountryChanged: (value) {
                      setState(() {
                        countryValue = value;
                      });
                    },
                    onStateChanged: (value) {
                      setState(() {
                        stateValue = value;
                      });
                    },
                    onCityChanged: (value) {
                      setState(() {
                        cityValue = value;
                      });
                    },
                  ),
                  verSpace,
                  getDefaultTextFiledFigma(
                    context,
                    "Phone Number",
                    txtPhoneNum,
                    getFontColor(context),
                  ),
                ],
              ),
            );
  }

  Widget buildToolbar(BuildContext context) {
    return getToolbarFigmaWidget(
              context,
              "Edit Shipping Address",
              () {
                backClick();
              },
              withBack: true,
              settingVisible: false,
            );
  }

  getRowWidget(String s, String t) {
    return Column(
      children: [
        Row(
          children: [
            SizedBox(
              width: FetchPixels.getPixelWidth(170),
              child:
                  getCustomFont(s, 14, black40, 1, fontWeight: FontWeight.w500),
            ),
            Expanded(
              flex: 1,
              child: getCustomFont(t, 14, getFontColor(context), 1,
                  fontWeight: FontWeight.w500),
            )
          ],
        ),
        Padding(
          padding: EdgeInsets.only(
              left: FetchPixels.getPixelWidth(170),
              top: FetchPixels.getPixelHeight(16),
              bottom: FetchPixels.getPixelHeight(16)),
          child: Divider(
              height: FetchPixels.getPixelHeight(1), color: Colors.black12),
        )
      ],
    );
  }
}
