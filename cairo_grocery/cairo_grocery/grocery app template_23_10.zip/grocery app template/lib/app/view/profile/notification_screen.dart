// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import '../../../base/color_data.dart';
import '../../../base/constant.dart';
import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _NotificationScreen();
  }
}

class _NotificationScreen extends State<NotificationScreen> {
  void backClick() {
    Constant.backToPrev(context);
  }

  List<String> notificationMainList = ["Today", "Yesterday"];

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 896);
    double defHorSpace = FetchPixels.getDefaultHorSpaceFigma(context);
    EdgeInsets edgeInsets = EdgeInsets.symmetric(horizontal: defHorSpace);
    return WillPopScope(
        child: Scaffold(
          backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
          appBar: getInVisibleAppBar(),
          body: Column(
            children: [
              buildToolbar(context),
              getVerSpace(FetchPixels.getPixelHeight(12)),
              buildExpand(context, edgeInsets, defHorSpace),
            ],
          ),
        ),
        onWillPop: () async {
          backClick();
          return false;
        });
  }

  Widget buildToolbar(BuildContext context) {
    return getToolbarFigmaWidget(
              context,
              "Notifications",
              () {
                backClick();
              },
              withBack: true,
              settingVisible: false,
            );
  }

  Expanded buildExpand(BuildContext context, EdgeInsets edgeInsets, double defHorSpace) {
    return Expanded(
              flex: 1,
              child: (notificationMainList.isEmpty)
                  ? Center(
                      child: getEmptyWidget(
                          context,
                          "empty_notification.svg",
                          "No Notifications Yet!",
                          "We’ll notify you when something arrives.",
                          "", () {
                        // Constant.sendToScreen(HomeScreen(), context);
                      }, withButton: false),
                    )
                  : SizedBox(
                      width: double.infinity,
                      height: double.infinity,
                      child: ListView.builder(
                        itemBuilder: (context, indexMain) {
                          return Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              getVerSpace(FetchPixels.getPixelHeight(20)),
                              getPaddingWidget(
                                  edgeInsets,
                                  getCustomFont(notificationMainList[indexMain],
                                      16, getFontColor(context), 1,
                                      fontWeight: FontWeight.w500)),
                              ListView.builder(
                                itemBuilder: (context, index) {
                                  return Container(
                                    width: double.infinity,
                                    padding:edgeInsets,
                                    margin: EdgeInsets.symmetric(horizontal: defHorSpace,vertical: FetchPixels.getPixelHeight(10)),
                                    height: FetchPixels.getPixelHeight(118),
                                    decoration: getButtonDecoration(
                                        Colors.white,
                                        withCorners: true,
                                        corner:
                                            FetchPixels.getPixelHeight(12),
                                        shadow: [
                                          const BoxShadow(
                                              color: Color.fromRGBO(155, 103,
                                                  103, 0.10999999940395355),
                                              offset: Offset(-5, 6),
                                              blurRadius: 28)
                                        ]),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          width:
                                              FetchPixels.getPixelHeight(50),
                                          height:
                                              FetchPixels.getPixelHeight(50),
                                          decoration: getButtonDecoration(
                                              "#FFF3F3".toColor(),
                                              withCorners: true,
                                              corner:
                                                  FetchPixels.getPixelHeight(
                                                      12)),
                                          margin: EdgeInsets.only(top: FetchPixels.getPixelHeight(20)),
                                          child: Stack(
                                            children: [
                                              Visibility(
                                                visible: indexMain==0,
                                                child: Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Icon(Icons.circle,
                                                      size: FetchPixels
                                                          .getPixelHeight(9),
                                                      color: getAccentColor(
                                                          context)),
                                                ),
                                              ),
                                              Center(
                                                child: getSvgImageWithSize(
                                                    context,
                                                    "Clock.svg",
                                                    FetchPixels
                                                        .getPixelHeight(24),
                                                    FetchPixels
                                                        .getPixelHeight(24)),
                                              )
                                            ],
                                          ),
                                        ),
                                        getHorSpace(FetchPixels.getPixelWidth(15)),
                                        Expanded(
                                          flex: 1,
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              getVerSpace(FetchPixels.getPixelHeight(22)),
                                              Row(
                                                children: [
                                                  Expanded(
                                                    flex: 1,
                                                    child: getCustomFont(
                                                        "Lorem ipsum dolor",
                                                        16,
                                                        getFontColor(context),
                                                        1,
                                                        fontWeight:
                                                            FontWeight.w700),
                                                  ),
                                                  getCustomFont("1h ago", 15,
                                                      black40, 1,
                                                      fontWeight:
                                                          FontWeight.w400)
                                                ],
                                              ),
                                              getVerSpace(
                                                  FetchPixels.getPixelHeight(
                                                      10)),
                                              getCustomFont(
                                                  "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore...",
                                                  14,
                                                  getFontColor(context),
                                                  2,
                                                  fontWeight:
                                                  FontWeight.w500),
                                              Expanded(
                                                flex: 1,
                                                child: getVerSpace(0),
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  );
                                },
                                shrinkWrap: true,
                                itemCount: 2,
                                primary: false,
                              )
                            ],
                          );
                        },
                        itemCount: notificationMainList.length,
                        primary: true,
                        padding: EdgeInsets.zero,
                        shrinkWrap: true,
                      ),
                    ),
            );
  }
}
