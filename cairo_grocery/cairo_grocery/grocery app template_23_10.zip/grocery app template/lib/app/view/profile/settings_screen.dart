// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:grocery/app/view/profile/notification_screen.dart';
import '../../../base/color_data.dart';
import '../../../base/constant.dart';
import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _SettingsScreen();
  }
}

class _SettingsScreen extends State<SettingsScreen> {
  void backClick() {
    Constant.backToPrev(context);
  }

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 896);
    return WillPopScope(
        child: Scaffold(
          backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
          appBar: getInVisibleAppBar(),
          body: Column(
            children: [
              buildToolbar(context),
              getVerSpace(FetchPixels.getPixelHeight(12)),
              buildExpand(context),
            ],
          ),
        ),
        onWillPop: () async {
          backClick();
          return false;
        });
  }

  Widget buildToolbar(BuildContext context) {
    return getToolbarFigmaWidget(
              context,
              "Settings",
              () {
                backClick();
              },
              withBack: true,
              settingVisible: false,
            );
  }

  Expanded buildExpand(BuildContext context) {
    return Expanded(
              flex: 1,
              child: ListView(
                primary: true,
                shrinkWrap: true,
                children: [
                  getRowWidget(context, "Notifications", "notify.svg", () {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => const NotificationScreen(),
                    ));

                  }),
                  getRowWidget(context, "Help & Support", "Info.svg", () {}),
                  getRowWidget(context, "Privacy Policy", "heart.svg", () {}),
                  getRowWidget(context, "Security", "Location.svg", () {}),
                  getRowWidget(
                      context, "Terms of Service", "Card.svg", () {}),
                ],
              ),
            );
  }
}
