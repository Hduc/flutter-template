// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import '../../../base/color_data.dart';
import '../../../base/constant.dart';
import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../routes/app_routes.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _ProfileScreen();
  }
}

class _ProfileScreen extends State<ProfileScreen> {
  void backClick() {
    Constant.backToPrev(context);

  }

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 896);
    double defHorSpace = FetchPixels.getDefaultHorSpaceFigma(context);
    return WillPopScope(
        child: Scaffold(
          backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
          appBar: getInVisibleAppBar(),
          body: Column(
            children: [
              buildToolbar(context),
              buildExpand(context, defHorSpace),
              buildButton(context, defHorSpace)
            ],
          ),
        ),
        onWillPop: () async {
          backClick();
          return false;
        });
  }

  Widget buildToolbar(BuildContext context) {
    return getToolbarFigmaWidget(
              context,
              "Profile",
              () {
                backClick();
              },
              withBack: true,
              settingVisible: false,
            );
  }

  Widget buildButton(BuildContext context, double defHorSpace) {
    return getButtonFigma(context, Colors.transparent, true, "Edit Profile",
                Colors.white, () {
              Constant.sendToNext(context, Routes.editProfileScreen);
            },
                EdgeInsets.symmetric(
                    horizontal: defHorSpace,
                    vertical: FetchPixels.getPixelHeight(18)),
                withGradient: true);
  }

  Expanded buildExpand(BuildContext context, double defHorSpace) {
    return Expanded(
              flex: 1,
              child: ListView(
                children: [
                  getCircleImage(context, "profile.png",
                      FetchPixels.getPixelHeight(100)),
                  Container(
                    padding: EdgeInsets.symmetric(
                        horizontal: defHorSpace,
                        vertical: FetchPixels.getPixelHeight(20)),
                    decoration: getButtonDecoration(Colors.white,
                        withCorners: true,
                        corner: getButtonCornersFigma(),
                        shadow: [
                          const BoxShadow(
                              color: Color.fromRGBO(
                                  155, 103, 103, 0.10999999940395355),
                              offset: Offset(-5, 6),
                              blurRadius: 28)
                        ]),
                    margin: EdgeInsets.symmetric(
                        horizontal: defHorSpace,
                        vertical: FetchPixels.getPixelHeight(20)),
                    width: double.infinity,
                    child: Column(
                      children: [
                        getRowWidget("First Name :", "Riyana"),
                        getRowWidget("Last Name :", "Wilson"),
                        getRowWidget("Email :", "riyanawilson@gmail.com"),
                        getRowWidget("Phone No. :", "(603) 555-0123"),
                      ],
                    ),
                  )
                ],
              ),
            );
  }

  getRowWidget(String s, String t) {
    return Column(
      children: [
        Row(
          children: [
            SizedBox(
              width: FetchPixels.getPixelWidth(170),
              child:
                  getCustomFont(s, 14, black40, 1, fontWeight: FontWeight.w500),
            ),
            Expanded(
              flex: 1,
              child: getCustomFont(t, 14, getFontColor(context), 1,
                  fontWeight: FontWeight.w500),
            )
          ],
        ),
        Padding(
          padding: EdgeInsets.only(
              left: FetchPixels.getPixelWidth(170),
              top: FetchPixels.getPixelHeight(16),
              bottom: FetchPixels.getPixelHeight(16)),
          child: Divider(
              height: FetchPixels.getPixelHeight(1), color: Colors.black12),
        )
      ],
    );
  }
}
