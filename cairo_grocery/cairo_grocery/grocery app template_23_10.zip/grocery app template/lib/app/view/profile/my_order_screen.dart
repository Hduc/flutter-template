// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:grocery/app/data/data_file.dart';

import '../../../base/color_data.dart';
import '../../../base/constant.dart';
import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../models/model_my_order.dart';
import '../../routes/app_routes.dart';

class MyOrderScreen extends StatefulWidget {
  const MyOrderScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _MyOrderScreen();
  }
}

class _MyOrderScreen extends State<MyOrderScreen> {
  void backClick() {
    Constant.sendToNext(context,Routes.homeScreenRoute,arguments: {Constant.homePos: 2});
  }

  List<ModelMyOrder> myOrderList =[];

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 896);
    double defHorSpace = FetchPixels.getDefaultHorSpaceFigma(context);
    return WillPopScope(
        child: Scaffold(
          backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
          appBar: getInVisibleAppBar(),
          body: Column(
            children: [
              buildToolbar(context),
              getVerSpace(FetchPixels.getPixelHeight(12)),
              buildExpand(context, defHorSpace),
            ],
          ),
        ),
        onWillPop: () async {
          backClick();
          return false;
        });
  }

  Expanded buildExpand(BuildContext context, double defHorSpace) {
    return Expanded(
              flex: 1,
              child: (myOrderList.isEmpty)
                  ? Center(
                      child: getEmptyWidget(
                          context,
                          "no_order.svg",
                          "No Orders Yet!",
                          "Explore more and shortlist some products",
                          "Go to Shop", () {
                            setState(() {
                              myOrderList=[];
                              myOrderList = DataFile.getMyOrders();
                            });
                        // Constant.sendToScreen(HomeScreen(), context);
                      },withButton: true),
                    )
                  : SizedBox(
                      width: double.infinity,
                      height: double.infinity,
                      child: ListView.builder(
                        itemBuilder: (context, index) {
                          ModelMyOrder modelMyOrder = myOrderList[index];
                          return InkWell(
                            onTap: () {
                              Constant.sendToNext(
                                  context, Routes.myOrderDetailScreen);
                            },
                            child: Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: defHorSpace,
                                  vertical: FetchPixels.getPixelHeight(10)),
                              width: double.infinity,
                              padding: EdgeInsets.symmetric(
                                  horizontal: FetchPixels.getPixelWidth(10),
                                  vertical: FetchPixels.getPixelHeight(10)),
                              decoration: getButtonDecoration(Colors.white,
                                  withCorners: true,
                                  corner: FetchPixels.getPixelHeight(12),
                                  shadow: [
                                    const BoxShadow(
                                        color: Color.fromRGBO(155, 103, 103,
                                            0.10999999940395355),
                                        offset: Offset(-5, 6),
                                        blurRadius: 28)
                                  ]),
                              height: FetchPixels.getPixelHeight(101),
                              child: Row(
                                children: [
                                  Container(
                                    width: FetchPixels.getPixelHeight(81),
                                    height: double.infinity,
                                    padding: EdgeInsets.symmetric(
                                        horizontal:
                                            FetchPixels.getPixelHeight(14),
                                        vertical:
                                            FetchPixels.getPixelHeight(16)),
                                    decoration: getButtonDecoration(
                                        modelMyOrder.colorBg!,
                                        withCorners: true,
                                        corner:
                                            FetchPixels.getPixelHeight(12)),
                                    child: Center(
                                      child: getAssetImage(
                                          context,
                                          modelMyOrder.image ?? "",
                                          double.infinity,
                                          double.infinity),
                                    ),
                                  ),
                                  getHorSpace(FetchPixels.getPixelWidth(12)),
                                  Expanded(
                                    flex: 1,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        getCustomFont(
                                            modelMyOrder.name ?? "",
                                            16,
                                            getFontColor(context),
                                            1,
                                            fontWeight: FontWeight.w700),
                                        getVerSpace(
                                            FetchPixels.getPixelHeight(6)),
                                        Row(
                                          children: [
                                            getCustomFont("\$", 16,
                                                getAccentColor(context), 1,
                                                fontWeight: FontWeight.w500),
                                            Expanded(
                                              flex: 1,
                                              child: getCustomFont(
                                                  modelMyOrder.price ?? "",
                                                  16,
                                                  getFontColor(context),
                                                  1,
                                                  fontWeight:
                                                      FontWeight.w500),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      getCustomFont(
                                          "25-02-2022", 14, black40, 1,
                                          fontWeight: FontWeight.w500),
                                      Container(
                                        // width: FetchPixels.getPixelWidth(82),
                                        padding: EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(10)),
                                        height:
                                            FetchPixels.getPixelHeight(26),
                                        decoration: getButtonDecoration(
                                            modelMyOrder.color!
                                                .withOpacity(0.09),
                                            withCorners: true,
                                            corner:
                                                FetchPixels.getPixelHeight(
                                                    12)),
                                        child: Center(
                                          child: getCustomFont(
                                              modelMyOrder.status ?? "",
                                              14,
                                              modelMyOrder.color!,
                                              1,
                                              fontWeight: FontWeight.w600),
                                        ),
                                      )
                                    ],
                                  )
                                ],
                              ),
                            ),
                          );
                        },
                        itemCount: myOrderList.length,
                        primary: true,
                        shrinkWrap: true,
                      ),
                    ),
            );
  }

  Widget buildToolbar(BuildContext context) {
    return getToolbarFigmaWidget(
              context,
              "My Orders",
              () {
                backClick();
              },
              withBack: true,
              settingVisible: false,
            );
  }

  getRowWidget(String s, String t) {
    return Column(
      children: [
        Row(
          children: [
            SizedBox(
              width: FetchPixels.getPixelWidth(170),
              child:
                  getCustomFont(s, 14, black40, 1, fontWeight: FontWeight.w500),
            ),
            Expanded(
              flex: 1,
              child: getCustomFont(t, 14, getFontColor(context), 1,
                  fontWeight: FontWeight.w500),
            )
          ],
        ),
        Padding(
          padding: EdgeInsets.only(
              left: FetchPixels.getPixelWidth(170),
              top: FetchPixels.getPixelHeight(16),
              bottom: FetchPixels.getPixelHeight(16)),
          child: Divider(
              height: FetchPixels.getPixelHeight(1), color: Colors.black12),
        )
      ],
    );
  }
}
