// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:grocery/app/data/data_file.dart';
import '../../../base/color_data.dart';
import '../../../base/constant.dart';
import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../models/address_model.dart';
import '../../routes/app_routes.dart';

class ShippingAddressScreen extends StatefulWidget {
  const ShippingAddressScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _ShippingAddressScreen();
  }
}

class _ShippingAddressScreen extends State<ShippingAddressScreen> {
  void backClick() {
    Constant.backToPrev(context);
  }

  List<AddressModel> addressList = [];
  List<String> popUpMenuList = ["Edit", "Delete"];

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 896);
    double defHorSpace = FetchPixels.getDefaultHorSpaceFigma(context);
    return WillPopScope(
        child: Scaffold(
          backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
          appBar: getInVisibleAppBar(),
          body: Column(
            children: [
              buildToolbar(context),
              getVerSpace(FetchPixels.getPixelHeight(12)),
              buildExpand(context, defHorSpace),
              buildButton(context, defHorSpace)
            ],
          ),
        ),
        onWillPop: () async {
          backClick();
          return false;
        });
  }

  Widget buildToolbar(BuildContext context) {
    return getToolbarFigmaWidget(
              context,
              "Shipping Address",
              () {
                backClick();
              },
              withBack: true,
              settingVisible: false,
            );
  }

  Widget buildButton(BuildContext context, double defHorSpace) {
    return getButtonFigma(
                context,
                Colors.transparent,
                true,
                "Add New Address",
                Colors.white,
                () {
                  Constant.sendToNext(context, Routes.addShippingAddressScreens);

                },
                EdgeInsets.symmetric(horizontal: defHorSpace,vertical: FetchPixels.getPixelHeight(15)));
  }

  Expanded buildExpand(BuildContext context, double defHorSpace) {
    return Expanded(
              flex: 1,
              child: (addressList.isEmpty)
                  ? Center(
                      child: getEmptyWidget(
                          context,
                          "no_add.svg",
                          "No Address Yet!",
                          "Add your address and lets get started.",
                          "Add Address", () {
                        setState(() {
                          addressList = [];
                          addressList = DataFile.getAddressList();
                        });
                        // Constant.sendToScreen(HomeScreen(), context);
                      }, withButton: true),
                    )
                  : SizedBox(
                      width: double.infinity,
                      height: double.infinity,
                      child: ListView.builder(
                        itemBuilder: (context1, index) {
                          return InkWell(
                            onTap: () {},
                            child: Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: defHorSpace,
                                  vertical: FetchPixels.getPixelHeight(10)),
                              width: double.infinity,
                              height: FetchPixels.getPixelHeight(152),
                              padding: EdgeInsets.symmetric(
                                  horizontal: defHorSpace,
                                  vertical: FetchPixels.getPixelHeight(20)),
                              decoration: getButtonDecoration(Colors.white,
                                  shadow: [
                                    const BoxShadow(
                                        color: Color.fromRGBO(155, 103, 103,
                                            0.10999999940395355),
                                        offset: Offset(-5, 6),
                                        blurRadius: 28)
                                  ],
                                  withCorners: true,
                                  corner: FetchPixels.getPixelHeight(15)),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Expanded(
                                        flex: 1,
                                        child: getCustomFont("Jerome Bell",
                                            16, getFontColor(context), 1,
                                            fontWeight: FontWeight.w700),
                                      ),
                                      PopupMenuButton(
                                        color: Colors.white,
                                        padding: EdgeInsets.zero,
                                        // getSvgImage(
                                        //     "Sort.svg",
                                        //     Constant.getPercentSize(
                                        //         cellHeight, 30)),
                                        itemBuilder: (context1) {
                                          return List.generate(
                                              popUpMenuList.length, (index) {
                                            return PopupMenuItem(
                                              padding: EdgeInsets.zero,
                                              height: 29,
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    height: (index ==
                                                            popUpMenuList
                                                                    .length -
                                                                1)
                                                        ? 30
                                                        : 29,
                                                    width: double.infinity,
                                                    padding: const EdgeInsets.only(
                                                        left: 10),
                                                    child: Align(
                                                      alignment: Alignment
                                                          .centerLeft,
                                                      child: getCustomFont(
                                                          popUpMenuList[
                                                              index],
                                                          15,
                                                          getFontColor(
                                                              context),
                                                          1,
                                                          fontWeight:
                                                              FontWeight
                                                                  .w500),
                                                    ),
                                                  ),
                                                  (index ==
                                                          popUpMenuList
                                                                  .length -
                                                              1)
                                                      ? Container()
                                                      : Divider(
                                                          color: Colors
                                                              .grey.shade300,
                                                          height: 1.5,
                                                        )
                                                ],
                                              ),

                                              onTap: () async {
                                                if (index == 1) {
                                                  Future.delayed(
                                                    Duration.zero,
                                                    () {
                                                      showDialog(
                                                        context: context,
                                                        builder: (context) {
                                                          // double height = Constant
                                                          //     .getHeightPercentSize(
                                                          //     30);
                                                          // double width = Constant
                                                          //     .getWidthPercentSize(
                                                          //     80);
                                                          // double radius = Constant
                                                          //     .getPercentSize(
                                                          //     height, 4);
                                                          // double imgSize =
                                                          // Constant
                                                          //     .getPercentSize(
                                                          //     height,
                                                          //     32);

                                                          return Dialog(
                                                            shape:
                                                                RoundedRectangleBorder(
                                                              borderRadius: BorderRadius
                                                                  .circular(FetchPixels
                                                                      .getPixelHeight(
                                                                          20)),
                                                            ),
                                                            elevation: 0.0,
                                                            insetPadding:
                                                                EdgeInsets
                                                                    .zero,
                                                            backgroundColor:
                                                                Colors
                                                                    .transparent,
                                                            child: Container(
                                                              height: FetchPixels
                                                                  .getPixelHeight(
                                                                      210),
                                                              width: FetchPixels
                                                                  .getPixelHeight(
                                                                      314),
                                                              padding: EdgeInsets.symmetric(
                                                                  horizontal:
                                                                      FetchPixels.getPixelHeight(
                                                                          10)),
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: getCurrentTheme(
                                                                        context)
                                                                    .scaffoldBackgroundColor,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            FetchPixels.getPixelHeight(20)),
                                                                boxShadow: [
                                                                  BoxShadow(
                                                                    color:
                                                                        shadowColor,
                                                                  ),
                                                                ],
                                                              ),
                                                              child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceEvenly,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  // SizedBox(
                                                                  //   height:
                                                                  //   Constant
                                                                  //       .getPercentSize(
                                                                  //     height,
                                                                  //     4,
                                                                  //   ),
                                                                  // ),
                                                                  getMultilineCustomFont(
                                                                      'Are you sure you want to delete\n this address?',
                                                                      22,
                                                                      getFontColor(
                                                                          context),
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w700,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .center,
                                                                      txtHeight:
                                                                          1.5),
                                                                  // SizedBox(
                                                                  //   height:
                                                                  //   Constant
                                                                  //       .getPercentSize(
                                                                  //     height,
                                                                  //     14,
                                                                  //   ),
                                                                  // ),
                                                                  Padding(
                                                                    padding: EdgeInsets.symmetric(
                                                                        horizontal:
                                                                            defHorSpace),
                                                                    child:
                                                                        Row(
                                                                      children: [
                                                                        Expanded(
                                                                          child: getButtonFigma(context,
                                                                              Colors.transparent, true, "Cancel", getAccentColor(context),
                                                                              () {
                                                                            Constant.backToFinish(context);
                                                                          }, EdgeInsets.zero,
                                                                              withGradient: false,
                                                                              isBorder: true,
                                                                              borderColor: getAccentColor(context)),
                                                                        ),
                                                                        getHorSpace(
                                                                            FetchPixels.getPixelHeight(20)),
                                                                        Expanded(
                                                                          child:
                                                                              getButtonFigma(
                                                                            context,
                                                                            Colors.transparent,
                                                                            true,
                                                                            "Delete",
                                                                            Colors.white,
                                                                            () {
                                                                              Constant.backToFinish(context);
                                                                            },
                                                                            EdgeInsets.zero,
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                  )
                                                                ],
                                                              ),
                                                            ),
                                                          );
                                                        },
                                                      );
                                                    },
                                                  );
                                                } else {
                                                  Future.delayed(
                                                    Duration.zero,
                                                    () {
                                                      Constant.sendToNext(
                                                          context, Routes.addShippingAddressScreens);
                                                    },
                                                  );
                                                  // Constant.sendToScreen(MyOrderScreen(), context);
                                                  // Constant.sendToNext(context,Routes.addShippingAddressScreen);
                                                }
                                              },
                                              // child: Text(popUpMenuList[index]),
                                            );
                                          });
                                        },
                                        child: getSvgImageWithSize(
                                            context,
                                            "menu_3.svg",
                                            FetchPixels.getPixelHeight(24),
                                            FetchPixels.getPixelHeight(24)),
                                      ),
                                    ],
                                  ),
                                  getMultilineCustomFont(
                                      "2972 Westheimer Rd.\nSanta Ana, Illinois 85486",
                                      14,
                                      getFontColor(context),
                                      fontWeight: FontWeight.w500,
                                      txtHeight: 1.5),
                                  getCustomFont(
                                    "(405) 555-0128",
                                    14,
                                    getFontColor(context),
                                    1,
                                    fontWeight: FontWeight.w500,
                                  )
                                ],
                              ),
                            ),
                          );
                        },
                        itemCount: addressList.length,
                        primary: true,
                        shrinkWrap: true,
                      ),
                    ),
            );
  }

  getRowWidget(String s, String t) {
    return Column(
      children: [
        Row(
          children: [
            SizedBox(
              width: FetchPixels.getPixelWidth(170),
              child:
                  getCustomFont(s, 14, black40, 1, fontWeight: FontWeight.w500),
            ),
            Expanded(
              flex: 1,
              child: getCustomFont(t, 14, getFontColor(context), 1,
                  fontWeight: FontWeight.w500),
            )
          ],
        ),
        Padding(
          padding: EdgeInsets.only(
              left: FetchPixels.getPixelWidth(170),
              top: FetchPixels.getPixelHeight(16),
              bottom: FetchPixels.getPixelHeight(16)),
          child: Divider(
              height: FetchPixels.getPixelHeight(1), color: Colors.black12),
        )
      ],
    );
  }
}
