// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:grocery/app/data/data_file.dart';
import '../../../base/color_data.dart';
import '../../../base/constant.dart';
import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../models/payment_card_model.dart';

class CardsScreen extends StatefulWidget {
  const CardsScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _CardsScreen();
  }
}

class _CardsScreen extends State<CardsScreen> {
  void backClick() {
    Constant.backToPrev(context);
  }

  List<PaymentCardModel> paymentCardsList = [];

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 896);
    double defHorSpace = FetchPixels.getDefaultHorSpaceFigma(context);
    return WillPopScope(
        child: Scaffold(
          backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
          appBar: getInVisibleAppBar(),
          body: Column(
            children: [
              buildToolbar(context),
              getVerSpace(FetchPixels.getPixelHeight(12)),
              buildExpand(context, defHorSpace),
              buildButton(context, defHorSpace)
            ],
          ),
        ),
        onWillPop: () async {
          backClick();
          return false;
        });
  }

  Widget buildButton(BuildContext context, double defHorSpace) {
    return getButtonFigma(
                context,
                Colors.transparent,
                true,
                "Add New Card",
                Colors.white,
                () {
                  showPaymentDialog(context,(){Constant.backToPrev(context);});


                },
                EdgeInsets.symmetric(horizontal: defHorSpace,vertical: FetchPixels.getPixelHeight(15)));
  }

  Expanded buildExpand(BuildContext context, double defHorSpace) {
    return Expanded(
              flex: 1,
              child: (paymentCardsList.isEmpty)
                  ? Center(
                      child: getEmptyWidget(
                          context,
                          "credit_card.svg",
                          "No Cards Yet!",
                          "Add your card and lets get started.",
                          "Add Card", () {
                        setState(() {
                          paymentCardsList = [];
                          paymentCardsList = DataFile.getPaymentCardList();
                        });
                        // Constant.sendToScreen(HomeScreen(), context);
                      }, withButton: true),
                    )
                  : SizedBox(
                      width: double.infinity,
                      height: double.infinity,
                      child: ListView.builder(
                        itemBuilder: (context1, index) {
                          PaymentCardModel addModel = paymentCardsList[index];
                          return InkWell(
                            onTap: () {},
                            child: Container(
                              width: double.infinity,
                              margin: EdgeInsets.symmetric(
                                  horizontal: defHorSpace,
                                  vertical: FetchPixels.getPixelHeight(11)),
                              height: FetchPixels.getPixelHeight(91),
                              padding:
                              EdgeInsets.symmetric(horizontal: defHorSpace),
                              decoration: getButtonDecoration(Colors.white,
                                  withCorners: true,
                                  corner: FetchPixels.getPixelHeight(12),
                                  shadow: [
                                    const BoxShadow(
                                        color: Color.fromRGBO(
                                            155, 103, 103, 0.10999999940395355),
                                        offset: Offset(-5, 6),
                                        blurRadius: 28)
                                  ]),
                              child: Row(
                                children: [
                                  getSvgImageWithSize(
                                      context,
                                      addModel.image ?? "",
                                      FetchPixels.getPixelHeight(44),
                                      FetchPixels.getPixelHeight(44)),
                                  getHorSpace(FetchPixels.getPixelWidth(12)),
                                  Expanded(
                                    flex: 1,
                                    child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          getCustomFont(addModel.name ?? "", 16,
                                              getFontColor(context), 1,
                                              fontWeight: FontWeight.w700),
                                          getVerSpace(
                                              FetchPixels.getPixelHeight(6)),
                                          getCustomFont(
                                              "xxxx xxxx xxxx ${addModel.desc}",
                                              14,
                                              getFontColor(context),
                                              1,
                                              fontWeight: FontWeight.w500),
                                        ]),
                                  ),
                                  getSvgImageWithSize(
                                      context,
                                      "menu_3.svg",
                                      FetchPixels.getPixelHeight(24),
                                      FetchPixels.getPixelHeight(24))
                                ],
                              ),
                            ) ,
                          );
                        },
                        itemCount: paymentCardsList.length,
                        primary: true,
                        shrinkWrap: true,
                      ),
                    ),
            );
  }

  Widget buildToolbar(BuildContext context) {
    return getToolbarFigmaWidget(
              context,
              "My Cards",
              () {
                backClick();
              },
              withBack: true,
              settingVisible: false,
            );
  }

  getRowWidget(String s, String t) {
    return Column(
      children: [
        Row(
          children: [
            SizedBox(
              width: FetchPixels.getPixelWidth(170),
              child:
                  getCustomFont(s, 14, black40, 1, fontWeight: FontWeight.w500),
            ),
            Expanded(
              flex: 1,
              child: getCustomFont(t, 14, getFontColor(context), 1,
                  fontWeight: FontWeight.w500),
            )
          ],
        ),
        Padding(
          padding: EdgeInsets.only(
              left: FetchPixels.getPixelWidth(170),
              top: FetchPixels.getPixelHeight(16),
              bottom: FetchPixels.getPixelHeight(16)),
          child: Divider(
              height: FetchPixels.getPixelHeight(1), color: Colors.black12),
        )
      ],
    );
  }
}
