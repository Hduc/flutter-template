import 'package:flutter/material.dart';
import 'package:grocery/base/color_data.dart';
import 'package:grocery/base/constant.dart';
import 'package:grocery/base/resizer/fetch_pixels.dart';
import 'package:grocery/base/widget_utils.dart';
import '../countrycodepicker/country_listview.dart';
import '../countrycodepicker/repository/countries_json.dart';

class ScreenSelectCountry extends StatefulWidget {
  const ScreenSelectCountry({super.key});

  @override
  State<StatefulWidget> createState() {
    return _ScreenSelectCountry();
  }
}

class _ScreenSelectCountry extends State<ScreenSelectCountry> {
  finish() {
    Constant.backToPrev(context);
  }

  TextEditingController edtController = TextEditingController();

  final Key _key = const Key("rfer");
  String selectedName = "";
  List<Map<String, String>> selectedCountry = countryCodes;
  List<Map<String, String>> filterList = countryCodes;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    FetchPixels(context);
    return getDetailWidget(context, () {
      finish();
    }, buildList(context));
  }

  ListView buildList(BuildContext context) {
    return ListView(
        padding: EdgeInsets.symmetric(
            horizontal: FetchPixels.getDefaultHorSpace(context)),
        shrinkWrap: true,
        primary: true,
        children: [
          getTopViewHeader(context,"Select a Country","",visibleSub: false),
          getSearchWidget(
            context,
            edtController,
            () {},
            (value) {
              filterList = [];
              if (value.isNotEmpty) {

                for (var element in selectedCountry) {
                  String valueGet = element["Name"] ?? "";
                  if (valueGet.contains(value) ||
                      valueGet.toUpperCase().contains(value) ||
                      valueGet.toLowerCase().contains(value)) {
                    filterList.add(element);
                  }
                }
                setState(() {});
              } else {
                setState(() {
                  filterList = selectedCountry;
                });
              }
            },
          ),
          getVerSpace(FetchPixels.getPixelHeight(25)),
          CountryListView(
            itemBuilder: (context, index, country) {
              double edtHeight =
                  FetchPixels.getPixelHeight(getEditIconSize()) * 1.4;
              double edtWidth = edtHeight * 1.4;
              return InkWell(
                onTap: () {
                  Navigator.of(context)
                      .pop({Constant.sendVal: country.name ?? ""});
                },
                child: Container(
                    width: double.infinity,
                    height: getEditHeight(),
                    padding: EdgeInsets.symmetric(
                        horizontal: FetchPixels.getPixelWidth(18)),
                    margin: EdgeInsets.symmetric(
                        vertical: FetchPixels.getPixelHeight(25)),
                    // padding: EdgeInsets.symmetric(
                    //     horizontal: FetchPixels.getPixelWidth(30),
                    //     vertical: FetchPixels.getPixelHeight(50)),
                    decoration: getButtonDecoration(Colors.white,
                        withCorners: true,
                        corner: getEditRadiusSize(),
                        withBorder: false,
                        shadow: [
                          BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                              spreadRadius: 7)
                        ]),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        getCircularImage(
                            context,
                            edtWidth,
                            edtHeight,
                            FetchPixels.getPixelHeight(10),
                            "flags/${country.code}.png",
                            boxFit: BoxFit.fill),
                        getHorSpace(FetchPixels.getPixelWidth(25)),
                        Expanded(
                          flex: 1,
                          child: getCustomFont(country.name ?? "",
                              getEditFontSize(), getFontColor(context), 1,
                              fontWeight: FontWeight.w500),
                        ),
                        getHorSpace(FetchPixels.getPixelWidth(25)),
                        getCustomFont("+${country.dialCode ?? ""}",
                            getEditFontSize(), getFontColor(context), 1,
                            fontWeight: FontWeight.w500)
                      ],
                    )),
              );
            },
            shrinkWrap: true,
            primary: false,
            countryJsonList: filterList,
            key: _key,
          )
        ],
      );
  }
}
