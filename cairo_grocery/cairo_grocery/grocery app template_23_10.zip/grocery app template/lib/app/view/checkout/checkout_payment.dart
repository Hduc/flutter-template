// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:grocery/base/color_data.dart';
import 'package:grocery/base/constant.dart';
import 'package:grocery/base/size_config.dart';

import '../../../base/review_slider.dart';
import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../data/data_file.dart';
import '../../models/payment_card_model.dart';
import '../../routes/app_routes.dart';

class CheckoutPayment extends StatefulWidget {
  const CheckoutPayment({super.key});

  @override
  State<StatefulWidget> createState() {
    return _CheckoutPayment();
  }
}

class _CheckoutPayment extends State<CheckoutPayment> {
  List<PaymentCardModel> paymentModelList = DataFile.getPaymentCardList();

  int currentStep = 2;
  int selectedAddress = 0;

  void _requestPop() {
    Constant.backToPrev(context);
  }

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 896);
    SizeConfig().init(context);
    double defHorSpace = FetchPixels.getDefaultHorSpaceFigma(context);
    return WillPopScope(
        child: Scaffold(
          backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
          appBar: getInVisibleAppBar(),
          body: buildColumn(context, defHorSpace),
        ),
        onWillPop: () async {
          _requestPop();
          return false;
        });
  }

  Column buildColumn(BuildContext context, double defHorSpace) {
    return Column(
          children: [
            getToolbarFigmaWidget(
              context,
              "Checkout",
              () {
                _requestPop();
              },
              withBack: false,
              settingVisible: true,
            ),
            ReviewSlider(
                optionStyle: TextStyle(
                  fontFamily: Constant.fontsFamily,
                  fontSize: Constant.getHeightPercentSize(1.7),
                  color: getFontColor(context),
                  fontWeight: FontWeight.w500,
                ),
                onChange: (index) {},
                initialValue: currentStep,
                circleDiameter: FetchPixels.getPixelHeight(22),
                // circleDiameter: Constant.getHeightPercentSize(5.5),
                isCash: false,
                width: double.infinity,
                options: DataFile.getOption()),
            getVerSpace(FetchPixels.getPixelHeight(30)),
            Expanded(
              flex: 1,
              child: ListView(
                primary: true,
                shrinkWrap: true,
                children: [
                  ListView.builder(
                    itemBuilder: (context, index) {
                      PaymentCardModel addModel = paymentModelList[index];
                      return Container(
                        width: double.infinity,
                        margin: EdgeInsets.symmetric(
                            horizontal: defHorSpace,
                            vertical: FetchPixels.getPixelHeight(11)),
                        height: FetchPixels.getPixelHeight(91),
                        padding:
                        EdgeInsets.symmetric(horizontal: defHorSpace),
                        decoration: getButtonDecoration(Colors.white,
                            withCorners: true,
                            corner: FetchPixels.getPixelHeight(12),
                            shadow: [
                              const BoxShadow(
                                  color: Color.fromRGBO(
                                      155, 103, 103, 0.10999999940395355),
                                  offset: Offset(-5, 6),
                                  blurRadius: 28)
                            ]),
                        child: Row(
                          children: [
                            getSvgImageWithSize(
                                context,
                                addModel.image ?? "",
                                FetchPixels.getPixelHeight(44),
                                FetchPixels.getPixelHeight(44)),
                            getHorSpace(FetchPixels.getPixelWidth(12)),
                            Expanded(
                              flex: 1,
                              child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  children: [
                                    getCustomFont(addModel.name ?? "", 16,
                                        getFontColor(context), 1,
                                        fontWeight: FontWeight.w700),
                                    getVerSpace(
                                        FetchPixels.getPixelHeight(6)),
                                    getCustomFont(
                                        "xxxx xxxx xxxx ${addModel.desc}",
                                        14,
                                        getFontColor(context),
                                        1,
                                        fontWeight: FontWeight.w500),
                                  ]),
                            ),
                            getSvgImageWithSize(
                                context,
                                (selectedAddress == index)
                                    ? "radio_se.svg"
                                    : "radio_un.svg",
                                FetchPixels.getPixelHeight(24),
                                FetchPixels.getPixelHeight(24))
                          ],
                        ),
                      );
                    },
                    shrinkWrap: true,
                    primary: false,
                    itemCount: paymentModelList.length,
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(25)),
                  Center(
                    child: InkWell(
                      onTap: () {
                        // showPaymentDialog(context);
                        showPaymentDialog(context,(){Constant.backToPrev(context);});
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.add,
                            color: getAccentColor(context),
                            size: FetchPixels.getPixelHeight(24),
                          ),
                          getCustomFont(
                              "Add New Card", 14, getAccentColor(context), 1,
                              fontWeight: FontWeight.w700)
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),

            getButtonFigma(
                context, Colors.transparent, true, "Next", Colors.white, () {
              Constant.sendToNext(context, Routes.checkoutConfirmScreen);
            },
                EdgeInsets.symmetric(
                    horizontal: defHorSpace,
                    vertical: FetchPixels.getPixelHeight(18)),
                withGradient: true)
          ],
        );
  }



}
