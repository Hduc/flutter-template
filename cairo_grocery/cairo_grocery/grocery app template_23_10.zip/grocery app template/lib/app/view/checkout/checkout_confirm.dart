// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:grocery/app/routes/app_routes.dart';
import 'package:grocery/base/color_data.dart';
import 'package:grocery/base/constant.dart';
import 'package:grocery/base/size_config.dart';

import '../../../base/review_slider.dart';
import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../data/data_file.dart';
import '../../models/payment_card_model.dart';
import '../../models/model_cart.dart';
import '../dialogs/custom_app_dialog.dart';

class CheckoutConfirm extends StatefulWidget {
  const CheckoutConfirm({super.key});

  @override
  State<StatefulWidget> createState() {
    return _CheckoutConfirm();
  }
}

class _CheckoutConfirm extends State<CheckoutConfirm> {
  List<PaymentCardModel> paymentModelList = DataFile.getPaymentCardList();

  int currentStep = 1;
  int selectedAddress = 0;

  void _requestPop() {
    Constant.backToPrev(context);
  }

  List<ModelCart> cartList = DataFile.getAllCartList();

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 896);
    SizeConfig().init(context);

    Widget verSpaceTotal = getVerSpace(FetchPixels.getPixelHeight(20));
    double defHorSpace = FetchPixels.getDefaultHorSpaceFigma(context);
    return WillPopScope(
        child: Scaffold(
          backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
          appBar: getInVisibleAppBar(),
          body: buildColumn(context, defHorSpace, verSpaceTotal),
        ),
        onWillPop: () async {
          _requestPop();
          return false;
        });
  }

  Column buildColumn(BuildContext context, double defHorSpace, Widget verSpaceTotal) {
    return Column(
          children: [
            getToolbarFigmaWidget(
              context,
              "Checkout",
              () {
                _requestPop();
              },
              withBack: false,
              settingVisible: true,
            ),
            ReviewSlider(
                optionStyle: TextStyle(
                  fontFamily: Constant.fontsFamily,
                  fontSize: Constant.getHeightPercentSize(1.7),
                  color: getFontColor(context),
                  fontWeight: FontWeight.w500,
                ),
                onChange: (index) {},
                initialValue: currentStep,
                circleDiameter: FetchPixels.getPixelHeight(22),
                // circleDiameter: Constant.getHeightPercentSize(5.5),
                isCash: false,
                width: double.infinity,
                options: DataFile.getOption()),
            getVerSpace(FetchPixels.getPixelHeight(30)),
            Expanded(
              flex: 1,
              child: ListView(
                primary: true,
                shrinkWrap: true,
                children: [
                  Container(
                    margin: EdgeInsets.symmetric(
                        horizontal: defHorSpace,
                        vertical: FetchPixels.getPixelHeight(10)),
                    width: double.infinity,
                    height: FetchPixels.getPixelHeight(92),
                    padding: EdgeInsets.symmetric(horizontal: defHorSpace),
                    decoration: getButtonDecoration(Colors.white,
                        withCorners: true,
                        corner: getButtonCornersFigma(),
                        shadow: [
                          const BoxShadow(
                              color: Color.fromRGBO(
                                  155, 103, 103, 0.10999999940395355),
                              offset: Offset(-5, 6),
                              blurRadius: 28)
                        ]),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        getCustomFont(
                            "Shipping Address", 16, getFontColor(context), 1,
                            fontWeight: FontWeight.w700),
                        getVerSpace(FetchPixels.getPixelHeight(8)),
                        getCustomFont(
                            "1901 Thornridge Cir. Shiloh, Hawaii 81063",
                            14,
                            getFontColor(context),
                            1,
                            fontWeight: FontWeight.w500)
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(
                        horizontal: defHorSpace,
                        vertical: FetchPixels.getPixelHeight(10)),
                    width: double.infinity,
                    height: FetchPixels.getPixelHeight(114),
                    padding: EdgeInsets.symmetric(horizontal: defHorSpace),
                    decoration: getButtonDecoration(Colors.white,
                        withCorners: true,
                        corner: getButtonCornersFigma(),
                        shadow: [
                          const BoxShadow(
                              color: Color.fromRGBO(
                                  155, 103, 103, 0.10999999940395355),
                              offset: Offset(-5, 6),
                              blurRadius: 28)
                        ]),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        getCustomFont(
                            "Payment Method", 16, getFontColor(context), 1,
                            fontWeight: FontWeight.w700),
                        getVerSpace(FetchPixels.getPixelHeight(11)),
                        Row(
                          children: [
                            getSvgImageWithSize(
                                context,
                                "paypal.svg",
                                FetchPixels.getPixelHeight(30),
                                FetchPixels.getPixelHeight(30)),
                            getHorSpace(FetchPixels.getPixelWidth(17)),
                            Expanded(
                              flex: 1,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  getCustomFont(
                                      "Paypal", 14, getFontColor(context), 1,
                                      fontWeight: FontWeight.w600),
                                  getVerSpace(FetchPixels.getPixelHeight(4)),
                                  getCustomFont("xxxx xxxx xxxx 5416", 14,
                                      getFontColor(context), 1,
                                      fontWeight: FontWeight.w500),
                                ],
                              ),
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(
                        horizontal: defHorSpace,
                        vertical: FetchPixels.getPixelHeight(10)),
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(
                        horizontal: defHorSpace,
                        vertical: FetchPixels.getPixelHeight(20)),
                    decoration: getButtonDecoration(Colors.white,
                        withCorners: true,
                        corner: getButtonCornersFigma(),
                        shadow: [
                          const BoxShadow(
                              color: Color.fromRGBO(
                                  155, 103, 103, 0.10999999940395355),
                              offset: Offset(-5, 6),
                              blurRadius: 28)
                        ]),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        getCustomFont(
                            "Cart Detail", 16, getFontColor(context), 1,
                            fontWeight: FontWeight.w700),
                        getVerSpace(FetchPixels.getPixelHeight(11)),
                        ListView.builder(
                          padding: EdgeInsets.zero,
                          itemCount: cartList.length,
                          itemBuilder: (context, index) {
                            ModelCart modelCart = cartList[index];
                            return Column(
                              children: [
                                getVerSpace(FetchPixels.getPixelHeight(20)),
                                Container(
                                  width: double.infinity,
                                  height: FetchPixels.getPixelHeight(65),
                                  margin: EdgeInsets.symmetric(
                                      vertical:
                                          FetchPixels.getPixelHeight(10)),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: FetchPixels.getPixelHeight(65),
                                        height: double.infinity,
                                        padding: EdgeInsets.symmetric(
                                            horizontal:
                                                FetchPixels.getPixelHeight(
                                                    11),
                                            vertical:
                                                FetchPixels.getPixelHeight(
                                                    11)),
                                        decoration: getButtonDecoration(
                                          modelCart.color!,
                                          withCorners: true,
                                          corner:
                                              FetchPixels.getPixelHeight(12),
                                        ),
                                        child: Center(
                                          child: getAssetImage(
                                              context,
                                              modelCart.image ?? "",
                                              double.infinity,
                                              double.infinity,
                                              boxFit: BoxFit.fill),
                                        ),
                                      ),
                                      getHorSpace(
                                          FetchPixels.getPixelWidth(12)),
                                      Expanded(
                                        flex: 1,
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            getCustomFont(
                                                modelCart.title ?? "",
                                                14,
                                                getFontColor(context),
                                                1,
                                                fontWeight: FontWeight.w700),
                                            getVerSpace(
                                                FetchPixels.getPixelHeight(
                                                    4)),
                                            Row(
                                              children: [
                                                getCustomFont(
                                                    "\$",
                                                    14,
                                                    getAccentColor(context),
                                                    1,
                                                    fontWeight:
                                                        FontWeight.w500),
                                                Expanded(
                                                  flex: 1,
                                                  child: getCustomFont(
                                                      "4.30",
                                                      14,
                                                      getFontColor(context),
                                                      1,
                                                      fontWeight:
                                                          FontWeight.w500),
                                                )
                                              ],
                                            )
                                          ],
                                        ),
                                      ),
                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Row(
                                            children: [
                                              getButtonContainer(
                                                  context, Icons.add, () {},
                                                  iconSize: 18, size: 22),
                                              getHorSpace(
                                                  FetchPixels.getPixelWidth(
                                                      10)),
                                              getCustomFont("1 kg", 13,
                                                  getFontColor(context), 1,
                                                  fontWeight:
                                                      FontWeight.w500),
                                              getHorSpace(
                                                  FetchPixels.getPixelWidth(
                                                      10)),
                                              getButtonContainer(context,
                                                  Icons.remove, () {},
                                                  iconSize: 18, size: 22),
                                            ],
                                          )
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                                getVerSpace(FetchPixels.getPixelHeight(20)),
                                Divider(
                                  height: FetchPixels.getPixelHeight(1),
                                  color: "#EEEEEE".toColor(),
                                )
                              ],
                            );
                          },
                          primary: false,
                          shrinkWrap: true,
                        )
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(
                        horizontal: defHorSpace,
                        vertical: FetchPixels.getPixelHeight(10)),
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(horizontal: defHorSpace),
                    decoration: getButtonDecoration(Colors.white,
                        withCorners: true,
                        corner: getButtonCornersFigma(),
                        shadow: [
                          const BoxShadow(
                              color: Color.fromRGBO(
                                  155, 103, 103, 0.10999999940395355),
                              offset: Offset(-5, 6),
                              blurRadius: 28)
                        ]),
                    child: Column(
                      children: [
                        verSpaceTotal,
                        getRow("Subtotal", "\$56.00"),
                        verSpaceTotal,
                        getRow("Shipping", "\$5.00"),
                        verSpaceTotal,
                        getRow("Tax (2%)", "\$2.00"),
                        verSpaceTotal,
                        getRow("Total", "\$28.45", isTotal: true),
                        verSpaceTotal,
                      ],
                    ),
                  ),
                ],
              ),
            ),
            getButtonFigma(
                context, Colors.transparent, true, "Confirm", Colors.white,
                () {
              showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return CustomAppDialog(
                      context,
                      () {
                        Constant.sendToNext(context,Routes.myOrderScreen);

                      },
                      "confirm.svg",
                      "Order Placed",
                      "Your order has been successfully\nCompleted!",
                      "Track Order",withBorderBtn: true,
                    );
                  });
            },
                EdgeInsets.symmetric(
                    horizontal: defHorSpace,
                    vertical: FetchPixels.getPixelHeight(18)),
                withGradient: true)
          ],
        );
  }

  getRow(String title, String total, {bool isTotal = false}) {
    Color fontBlack = getFontColor(context);
    return Row(
      children: [
        Expanded(
          flex: 1,
          child: (!isTotal)
              ? getCustomFont(title, 16, fontBlack, 1,
                  fontWeight: FontWeight.w500)
              : getCustomFont(title, 16, fontBlack, 1,
                  fontWeight: FontWeight.w700),
        ),
        (isTotal)
            ? getCustomFont(total, 16, getAccentColor(context), 1,
                fontWeight: FontWeight.w700)
            : getCustomFont(total, 16, fontBlack, 1,
                fontWeight: FontWeight.w700)
      ],
    );
  }
}
