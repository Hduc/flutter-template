// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:grocery/base/color_data.dart';
import 'package:grocery/base/constant.dart';
import 'package:grocery/base/resizer/fetch_pixels.dart';
import 'package:grocery/base/widget_utils.dart';


class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _SearchScreen();
  }
}

class _SearchScreen extends State<SearchScreen> {

  List<String> suggestionlist = [
    "tomato",
    "vegetables",
    "fruits"
  ];

  List<String> selectedSearchList = ["potato"];
  List<String> popularSearchList = [
    "tomato",
    "cabbage",
    "eggplant",
    "orange",
    "potato",
    "carrot",
    "chips",
    "butter",
    "milk",
    "onion",
    "cucumber"
  ];

  checkData() {
    String value = searchController.value.text;
    filteredList.clear();
    if (value.isNotEmpty) {
      for (var element in suggestionlist) {
        if (element.contains(value)) {
          filteredList.add(element);
        }
      }
      valChange.value = !valChange.value;
    } else {
      valChange.value = !valChange.value;
    }
  }

  List<String> filteredList = [];
  TextEditingController searchController = TextEditingController(text: "t");
  ValueNotifier<bool> valChange = ValueNotifier(false);

  backClick() {
    Constant.backToPrev(context);
  }

  @override
  Widget build(BuildContext context) {
    FetchPixels(context, mockUpWidth1: 414, mockUpHeight1: 1007);
    double defSpace = FetchPixels.getDefaultHorSpaceFigma(context);
    EdgeInsets edgeInsets = EdgeInsets.symmetric(horizontal: defSpace);

    return WillPopScope(
      onWillPop: () async {
        backClick();
        return false;
      },
      child: Scaffold(
        body: buildColumn(context, edgeInsets, defSpace),
        backgroundColor: getCurrentTheme(context).scaffoldBackgroundColor,
        appBar: getInVisibleAppBar(),
      ),
    );
  }

  Column buildColumn(BuildContext context, EdgeInsets edgeInsets, double defSpace) {
    return Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          getToolbarFigmaWidget(context, "Search", () {
            backClick();
          }, withBack: true, settingVisible: false),
          getPaddingWidget(
              edgeInsets,
              getSearchFigmaWidget(
                context,
                searchController,
                () {},
                (value) {
                  filteredList.clear();
                  if (value.isNotEmpty) {
                    for (var element in suggestionlist) {
                      if (element.contains(value)) {
                        filteredList.add(element);
                      }
                    }
                    valChange.value = !valChange.value;
                  } else {
                    valChange.value = !valChange.value;
                  }
                },
              )),
          getVerSpace(FetchPixels.getPixelWidth(10)),
          Expanded(flex: 1,child: ValueListenableBuilder(
            builder: (context, value, child) {
              return (filteredList.isNotEmpty)
                  ? SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ListView.builder(
                      itemBuilder: (context, index) {
                        return Container(
                          margin: EdgeInsets.symmetric(
                            horizontal: defSpace,vertical: FetchPixels.getPixelHeight(10)
                            // vertical: Constant.getPercentSize(
                            //     appBarPadding, 65)
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment:
                            CrossAxisAlignment.center,
                            children: [
                              getSvgImageWithSize(context,"Rotate_Left.svg",FetchPixels.getPixelHeight(26), FetchPixels.getPixelHeight(26)),
                              getHorSpace(
                                  FetchPixels.getPixelWidth(13)),
                              Expanded(
                                flex: 1,
                                child: getCustomFont(
                                    filteredList[index],
                                    14,
                                    getFontColor(context),
                                    1,
                                    fontWeight: FontWeight.w500),
                              )
                            ],
                          ),
                        );
                      },
                      padding: EdgeInsets.zero,
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: filteredList.length,
                    ),
                    Padding(
                      padding:
                      EdgeInsets.symmetric(horizontal: defSpace),
                      child: Divider(color: Colors.grey.shade400),
                    ),
                    Padding(
                      padding:
                      EdgeInsets.symmetric(horizontal: defSpace),
                      child: getCustomFont("Popular Searches", 15,
                          getFontColor(context), 1,
                          fontWeight: FontWeight.w700),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: defSpace,
                          vertical: defSpace),
                      child: Wrap(
                        spacing: 6.0,
                        runSpacing: 6.0,
                        children: List.generate(
                            popularSearchList.length, (index) {
                          return Container(
                              decoration: getButtonDecoration(
                                  (selectedSearchList.contains(
                                      popularSearchList[index]))
                                      ? getAccentColor(context)
                                      : Colors.transparent,
                                  withCorners:  true,
                                  corner: FetchPixels.getPixelHeight(10),withBorder:  !(selectedSearchList.contains(
                                  popularSearchList[index])),borderColor: getCurrentTheme(context).focusColor),
                              padding: EdgeInsets.symmetric(
                                  horizontal: FetchPixels.getPixelHeight(13),
                                  vertical: FetchPixels.getPixelHeight(10)),
                              child:getCustomFont(popularSearchList[index], 13,  (selectedSearchList.contains(
                                  popularSearchList[index]))
                                  ? Colors.white
                                  : getFontColor(context), 1)
                          );
                        }),
                      ),
                    )
                  ],
                ),
              )
                  : Center(
                child: SingleChildScrollView(
                  child: Center(
                    child: getEmptyWidget(context,
                        "empty_search.svg",
                        "No Searches",
                        "You have no recent searches.",
                        "",
                            () {},
                        withButton: false),
                  ),
                ),
              );
            },
            valueListenable: valChange,
          ),)
        ],
      );
  }





  @override
  void initState() {
    super.initState();
    checkData();
  }
}
