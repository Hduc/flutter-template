import 'package:flutter/material.dart';
import 'package:grocery/app/routes/app_routes.dart';
import 'package:grocery/app/view/category/category_list_screen.dart';
import 'package:grocery/app/view/category/category_sub_list_screen.dart';
import 'package:grocery/app/view/category/product_detail_screen.dart';
import 'package:grocery/app/view/checkout/checkout_address.dart';
import 'package:grocery/app/view/checkout/checkout_confirm.dart';
import 'package:grocery/app/view/checkout/checkout_payment.dart';
import 'package:grocery/app/view/login/screen_change_pass.dart';
import 'package:grocery/app/view/login/screen_forgot_pass.dart';
import 'package:grocery/app/view/login/screen_login.dart';
import 'package:grocery/app/view/login/screen_select_country.dart';
import 'package:grocery/app/view/login/screen_sign_up.dart';
import 'package:grocery/app/view/login/screen_verify_code.dart';
import 'package:grocery/app/view/profile/add_shipping_address_screen.dart';
import 'package:grocery/app/view/profile/cards_screen.dart';
import 'package:grocery/app/view/profile/edt_profile_screen.dart';
import 'package:grocery/app/view/profile/my_order_detail_screen.dart';
import 'package:grocery/app/view/profile/my_order_screen.dart';
import 'package:grocery/app/view/profile/notification_screen.dart';
import 'package:grocery/app/view/profile/profile_screen.dart';
import 'package:grocery/app/view/profile/settings_screen.dart';
import 'package:grocery/app/view/profile/shipping_address_screen.dart';
import 'package:grocery/app/view/search/search_screen.dart';
import 'package:grocery/app/view/splash_screen.dart';

import '../view/home/home_screen.dart';
import '../view/intro.dart';

class AppPages {
  static const initialRoute = Routes.homeRoute;
  static Map<String, WidgetBuilder> routes = {
    Routes.homeRoute: (context) => const SplashScreen(),
    Routes.homeScreenRoute: (context) => const HomeScreen(),
    Routes.introRoute: (context) => const IntroView(),
    Routes.loginRoute: (context) => const ScreenLogin(),
    Routes.signUpRoute: (context) => const ScreenSignUp(),
    Routes.verifyCodeRoute: (context) => const ScreenVerifyCode(),
    Routes.changePassRoute: (context) => const ScreenChangePass(),
    Routes.forgotPassRoute: (context) => const ScreenForgotPass(),
    Routes.selectCountryPath: (context) => const ScreenSelectCountry(),
    Routes.categoryListPath: (context) => const CategoryListScreen(),
    Routes.subListCategoryPath: (context) => const CategorySubListScreen(),
    Routes.searchScreenPath: (context) => const SearchScreen(),
    Routes.detailScreenPath: (context) => const ProductDetailScreen(),
    Routes.checkoutAddScreen: (context) => const CheckoutAddress(),
    Routes.checkoutPaymentScreen: (context) => const CheckoutPayment(),
    Routes.checkoutConfirmScreen: (context) => const CheckoutConfirm(),
    Routes.profileScreen: (context) => const ProfileScreen(),
    Routes.editProfileScreen: (context) => const EditProfileScreen(),
    Routes.myOrderScreen: (context) => const MyOrderScreen(),
    Routes.myOrderDetailScreen: (context) => const MyOrderDetailScreen(),
    Routes.shippingAddressScreen: (context) => const ShippingAddressScreen(),
    Routes.addShippingAddressScreens: (context) => const AddShippingAddressScreen(),
    Routes.cardScreen: (context) =>const CardsScreen(),
    Routes.settingsScreen: (context) =>const SettingsScreen(),
    Routes.notificationScreenPath: (context) =>const NotificationScreen(),
    // Routes.discoverDetailRoute: (context) => const DiscoverDetailScreen(),
    // Routes.creatorListScreenRoute: (context) =>  const AllCreatorsList(),
    // Routes.profileScreenRoute: (context) =>  const ProfileScreen(),
    // Routes.editProfileScreenRoute: (context) =>  const EditProfileScreen(),
    // Routes.collectibleScreenRoute: (context) =>  const CollectibleScreen(),
    // Routes.collectibleDetailScreenRoute: (context) =>  const CollectibleDetailScreen(),
    // Routes.trendingListScreenRoute: (context) =>  const TrendingListScreen(),
    // Routes.topCollectionListScreenRoute: (context) =>  const TopCollectionList(),
  };
}
